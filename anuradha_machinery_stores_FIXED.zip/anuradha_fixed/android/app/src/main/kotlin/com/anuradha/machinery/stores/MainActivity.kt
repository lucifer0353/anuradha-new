package com.anuradha.machinery.stores

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
