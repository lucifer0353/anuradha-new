import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;
  AppLocalizations(this.locale);

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations) ?? AppLocalizations(const Locale('en'));
  }

  static const Map<String, Map<String, String>> _localizedValues = {
    'en': {
      'dashboard': 'Dashboard',
      'new_invoice': 'New Invoice',
      'customers': 'Customers',
      'products': 'Products',
      'invoice_history': 'Invoice History',
      'settings': 'Settings',
      'add_customer': 'Add Customer',
      'edit_customer': 'Edit Customer',
      'customer_details': 'Customer Details',
      'search_customer': 'Search Customer...',
      'customer_name': 'Customer Name',
      'mobile_number': 'Mobile Number',
      'gat_number': 'Gat / Survey Number',
      'area': 'Area',
      'crop': 'Crop',
      'remarks': 'Remarks',
      'address': 'Address',
      'gstin': 'GSTIN',
      'add_product': 'Add Product',
      'edit_product': 'Edit Product',
      'search_product': 'Search Product...',
      'product_name': 'Product Name',
      'hsn_code': 'HSN Code',
      'cml_number': 'CML Number',
      'batch_number': 'Batch Number',
      'company_rate': 'Company Rate',
      'sale_rate': 'Sale Rate',
      'gst_percentage': 'GST %',
      'unit_type': 'Unit Type',
      'save': 'Save',
      'delete': 'Delete',
      'cancel': 'Cancel',
      'confirm_delete': 'Are you sure you want to delete this permanently?',
      'payment_status': 'Payment Status',
      'grand_total': 'Grand Total',
      'taxable_amount': 'Taxable Amount',
      'total_gst': 'Total GST',
    },
    'mr': {
      'dashboard': 'डॅशबोर्ड',
      'new_invoice': 'नवीन पावती',
      'customers': 'ग्राहक व्यवस्थापन',
      'products': 'उत्पादने (माल)',
      'invoice_history': 'पावत्यांचा इतिहास',
      'settings': 'ॲप सेटिंग्ज',
      'add_customer': 'नवीन ग्राहक जोडा',
      'edit_customer': 'ग्राहकाची माहिती सुधारा',
      'customer_details': 'ग्राहकाचा तपशील',
      'search_customer': 'नाव, मोबाईल किंवा GSTIN ने शोधा...',
      'customer_name': 'ग्राहकाचे नाव',
      'mobile_number': 'मोबाईल नंबर',
      'gat_number': 'गट / सर्व्हे नंबर',
      'area': 'परिसर / गाव',
      'crop': 'पीक (Crop)',
      'remarks': 'टीप (Remarks)',
      'address': 'पत्ता',
      'gstin': 'GSTIN नंबर',
      'add_product': 'नवीन उत्पादन जोडा',
      'edit_product': 'उत्पादन सुधारा',
      'search_product': 'उत्पादनाचे नाव किंवा HSN ने शोधा...',
      'product_name': 'उत्पादनाचे नाव',
      'hsn_code': 'HSN कोड',
      'cml_number': 'CML नंबर',
      'batch_number': 'बॅच नंबर',
      'company_rate': 'कंपनी दर (खरेदी)',
      'sale_rate': 'विक्री दर',
      'gst_percentage': 'जीएसटी टक्केवारी (%)',
      'unit_type': 'युनिटचा प्रकार (Unit)',
      'save': 'जतन करा',
      'delete': 'डिलीट करा',
      'cancel': 'रद्द करा',
      'confirm_delete': 'तुम्हाला नक्की हे कायमचे डिलीट करायचे आहे का?',
      'payment_status': 'पेमेंटची स्थिती',
      'grand_total': 'एकूण देय रक्कम',
      'taxable_amount': 'करपात्र रक्कम',
      'total_gst': 'एकूण जीएसटी',
    }
  };

  String translate(String key) {
    return _localizedValues[locale.languageCode]?[key] ?? key;
  }
}

class AppLocalizationsDelegate extends LocalizationsDelegate<AppLocalizations> {
  const AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'mr'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async => AppLocalizations(locale);

  @override
  bool shouldReload(AppLocalizationsDelegate old) => false;
}
