import 'package:flutter/material.dart';
import '../../data/models/customer_model.dart';
import '../../data/models/india_states.dart';
import '../../data/repositories/customer_repository.dart';
import '../widgets/phone_field_widget.dart';

class CustomerFormScreen extends StatefulWidget {
  final CustomerModel? customer;
  const CustomerFormScreen({this.customer, super.key});
  @override
  State<CustomerFormScreen> createState() => _CustomerFormScreenState();
}

class _CustomerFormScreenState extends State<CustomerFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl       = TextEditingController();
  final _mobileCtrl     = TextEditingController();
  final _addressCtrl    = TextEditingController();
  final _stateCodeCtrl  = TextEditingController();
  final _districtCtrl   = TextEditingController();
  final _subDistrictCtrl= TextEditingController();
  final _gatCtrl        = TextEditingController();
  final _areaCtrl       = TextEditingController();
  final _cropCtrl       = TextEditingController();
  final _gstinCtrl      = TextEditingController();
  final _remarksCtrl    = TextEditingController();

  String _selectedCountryCode = '+91';
  String? _selectedState;
  String _selectedAreaUnit = 'Acre (एकर)';

  final _customerRepo = CustomerRepository();
  List<CustomerModel> _existingSuggestions = [];

  @override
  void initState() {
    super.initState();
    if (widget.customer != null) {
      final c = widget.customer!;
      final mobile = c.mobile;
      if (mobile.startsWith('+')) {
        final parts = mobile.split(' ');
        if (parts.length >= 2) {
          _selectedCountryCode = parts[0];
          _mobileCtrl.text = parts.sublist(1).join('');
        } else {
          _mobileCtrl.text = mobile;
        }
      } else {
        _mobileCtrl.text = mobile;
      }
      _nameCtrl.text        = c.name;
      _addressCtrl.text     = c.address;
      _stateCodeCtrl.text   = c.stateCode;
      _districtCtrl.text    = c.district;
      _subDistrictCtrl.text = c.subDistrict;
      _gatCtrl.text         = c.gatNumber;
      _areaCtrl.text        = c.area;
      _cropCtrl.text        = c.crop;
      _gstinCtrl.text       = c.gstin;
      _remarksCtrl.text     = c.remarks;
      _selectedState        = kIndianStates.contains(c.state) ? c.state : null;
      _selectedAreaUnit     = kAreaUnits.contains(c.areaUnit) ? c.areaUnit : 'Acre (एकर)';
    }
  }

  void _checkDuplicate(String value) async {
    if (value.trim().isEmpty) { setState(() { _existingSuggestions = []; }); return; }
    final results = await _customerRepo.searchCustomers(value);
    setState(() {
      _existingSuggestions = results.where((c) => c.id != widget.customer?.id).toList();
    });
  }

  Widget _sectionHeader(String title) => Padding(
    padding: const EdgeInsets.only(top: 16, bottom: 8),
    child: Row(children: [
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.blueGrey)),
      const SizedBox(width: 8),
      const Expanded(child: Divider()),
    ]),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.customer == null ? 'Add New Customer' : 'Edit Customer Profile'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [

            // ── Basic Info ──
            _sectionHeader('👤 Basic Information'),

            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Customer Full Name *',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
              ),
              onChanged: _checkDuplicate,
              validator: (v) => v!.trim().isEmpty ? 'Please enter name' : null,
            ),

            if (_existingSuggestions.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.amber[50],
                  border: Border.all(color: Colors.amber[800]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    Icon(Icons.warning_amber_rounded, color: Colors.amber[800], size: 18),
                    const SizedBox(width: 6),
                    Text('Similar customer already exists!',
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.amber[900], fontSize: 12)),
                  ]),
                  const Divider(color: Colors.amber),
                  ..._existingSuggestions.map((c) => Text('• ${c.name} (${c.mobile})',
                    style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold))),
                ]),
              ),
            ],

            const SizedBox(height: 12),
            PhoneFieldWidget(
              controller: _mobileCtrl,
              label: 'Mobile Number *',
              initialCountryCode: _selectedCountryCode,
              isRequired: true,
            ),

            const SizedBox(height: 12),
            TextFormField(
              controller: _gstinCtrl,
              decoration: const InputDecoration(
                labelText: 'Customer GSTIN (If Available)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.badge),
              ),
              textCapitalization: TextCapitalization.characters,
            ),

            // ── Address ──
            _sectionHeader('📍 Address Details'),

            TextFormField(
              controller: _addressCtrl,
              decoration: const InputDecoration(
                labelText: 'Village / Town / Street Address',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.home),
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 12),

            // State dropdown
            DropdownButtonFormField<String>(
              value: _selectedState,
              decoration: const InputDecoration(
                labelText: 'State',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.map),
              ),
              isExpanded: true,
              hint: const Text('Select State'),
              items: kIndianStates.map((s) => DropdownMenuItem(value: s, child: Text(s))).toList(),
              onChanged: (v) => setState(() { _selectedState = v; }),
            ),
            const SizedBox(height: 12),

            // State Code
            TextFormField(
              controller: _stateCodeCtrl,
              decoration: const InputDecoration(
                labelText: 'State Code (e.g. MH, UP, KA)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.code),
              ),
              textCapitalization: TextCapitalization.characters,
              maxLength: 4,
            ),
            const SizedBox(height: 4),

            // District + Sub-District
            Row(children: [
              Expanded(
                child: TextFormField(
                  controller: _districtCtrl,
                  decoration: const InputDecoration(
                    labelText: 'District',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: TextFormField(
                  controller: _subDistrictCtrl,
                  decoration: const InputDecoration(
                    labelText: 'Sub-District / Taluka',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
            ]),

            // ── Farm Details ──
            _sectionHeader('🌾 Farm Details'),

            // Gat / Survey No
            TextFormField(
              controller: _gatCtrl,
              decoration: const InputDecoration(
                labelText: 'Gat / Survey No.',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.numbers),
              ),
            ),
            const SizedBox(height: 12),

            // Area + Unit
            Row(children: [
              Expanded(
                flex: 2,
                child: TextFormField(
                  controller: _areaCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                    labelText: 'Area (क्षेत्रफळ)',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.crop_square),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                flex: 3,
                child: DropdownButtonFormField<String>(
                  value: _selectedAreaUnit,
                  decoration: const InputDecoration(
                    labelText: 'Unit',
                    border: OutlineInputBorder(),
                  ),
                  isExpanded: true,
                  items: kAreaUnits.map((u) => DropdownMenuItem(
                    value: u,
                    child: Text(u, style: const TextStyle(fontSize: 13)),
                  )).toList(),
                  onChanged: (v) => setState(() { _selectedAreaUnit = v!; }),
                ),
              ),
            ]),
            const SizedBox(height: 12),

            TextFormField(
              controller: _cropCtrl,
              decoration: const InputDecoration(
                labelText: 'Main Crop Name',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.grass),
              ),
            ),
            const SizedBox(height: 12),

            TextFormField(
              controller: _remarksCtrl,
              decoration: const InputDecoration(
                labelText: 'Special Remarks',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.note),
              ),
              maxLines: 2,
            ),
            const SizedBox(height: 24),

            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.green,
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  final fullMobile = '$_selectedCountryCode ${_mobileCtrl.text.trim()}';
                  final c = CustomerModel(
                    id: widget.customer?.id,
                    name: _nameCtrl.text.trim(),
                    mobile: fullMobile,
                    address: _addressCtrl.text.trim(),
                    state: _selectedState ?? '',
                    district: _districtCtrl.text.trim(),
                    subDistrict: _subDistrictCtrl.text.trim(),
                    stateCode: _stateCodeCtrl.text.trim().toUpperCase(),
                    gatNumber: _gatCtrl.text.trim(),
                    area: _areaCtrl.text.trim(),
                    areaUnit: _selectedAreaUnit,
                    crop: _cropCtrl.text.trim(),
                    gstin: _gstinCtrl.text.trim().toUpperCase(),
                    remarks: _remarksCtrl.text.trim(),
                  );
                  if (widget.customer == null) {
                    await _customerRepo.insertCustomer(c);
                  } else {
                    await _customerRepo.updateCustomer(c);
                  }
                  if (mounted) Navigator.pop(context);
                }
              },
              child: const Text('Save Customer Profile',
                style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
