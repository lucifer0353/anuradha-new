import 'package:flutter/material.dart';
import '../../data/models/product_model.dart';
import '../../data/repositories/product_repository.dart';

class ProductFormScreen extends StatefulWidget {
  final ProductModel? product;
  const ProductFormScreen({this.product, super.key});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameCtrl = TextEditingController();
  final _hsnCtrl = TextEditingController();
  final _cmlCtrl = TextEditingController();
  final _batchCtrl = TextEditingController();
  final _companyRateCtrl = TextEditingController();
  final _saleRateCtrl = TextEditingController();
  final _gstCtrl = TextEditingController();
  String _selectedUnit = 'Piece';
  final _customUnitCtrl = TextEditingController();
  bool _showCustomUnit = false;

  final _productRepo = ProductRepository();
  List<ProductModel> _existingProductSuggestions = []; // मॅच होणारे जुने प्रॉडक्ट्स

  final List<String> _units = [
    'Piece', 'Bundle', 'Foot', 'Centimeter', 'Millimeter', 'Inch', 
    'Kg', 'Gram', 'Millileter', 'Liter', 'Meter', 'Box', 'Packet', 'Custom'
  ];

  @override
  void initState() {
    super.initState();
    if (widget.product != null) {
      _nameCtrl.text = widget.product!.name;
      _hsnCtrl.text = widget.product!.hsnCode;
      _cmlCtrl.text = widget.product!.cmlNumber;
      _batchCtrl.text = widget.product!.batchNumber;
      _companyRateCtrl.text = widget.product!.companyRate.toString();
      _saleRateCtrl.text = widget.product!.saleRate.toString();
      _gstCtrl.text = widget.product!.gstPercentage.toString();
      _selectedUnit = widget.product!.unitType;
    }
  }

  // नाव टाईप करताना डेटाबेसमधून मॅचिंग उत्पादन शोधणे
  void _checkDuplicateProduct(String value) async {
    if (value.trim().isEmpty) {
      setState(() { _existingProductSuggestions = []; });
      return;
    }
    final results = await _productRepo.searchProducts(value);
    setState(() {
      // एडिट करताना स्वतःचे नाव सोडून इतर डुप्लिकेट दाखवणे
      _existingProductSuggestions = results.where((p) => p.id != widget.product?.id).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.product == null ? 'Add New Product' : 'Edit Product Details'),
        backgroundColor: Colors.orange,
        foregroundColor: Colors.white,
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameCtrl,
              decoration: const InputDecoration(
                labelText: 'Product Name*', 
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.shopping_bag),
              ),
              onChanged: _checkDuplicateProduct, // टाईप करताना चेक होणार
              validator: (v) => v!.trim().isEmpty ? 'Please enter product name' : null,
            ),

            // ⚠️ डुप्लिकेट अलर्ट सजेशन बॉक्स
            if (_existingProductSuggestions.isNotEmpty) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.orange[50],
                  border: Border.all(color: Colors.orange[800]!),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.warning_amber_rounded, color: Colors.orange[800], size: 18),
                        const SizedBox(width: 6),
                        Text(
                          'Product Already Exists! Matches found:',
                          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange[900], fontSize: 12),
                        ),
                      ],
                    ),
                    const Divider(color: Colors.orange),
                    ..._existingProductSuggestions.map((prod) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 2.0),
                      child: Text('• ${prod.name} (Sale Rate: Rs. ${prod.saleRate}, HSN: ${prod.hsnCode})', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                    )),
                  ],
                ),
              ),
            ],

            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _hsnCtrl,
                    decoration: const InputDecoration(labelText: 'HSN Code (Optional)', border: OutlineInputBorder()),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      DropdownButtonFormField<String>(
                        value: _units.contains(_selectedUnit) ? _selectedUnit : 'Custom',
                        decoration: const InputDecoration(labelText: 'Unit Type', border: OutlineInputBorder()),
                        items: _units.map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(),
                        onChanged: (val) => setState(() {
                          _selectedUnit = val!;
                          _showCustomUnit = val == 'Custom';
                          if (!_showCustomUnit) _customUnitCtrl.clear();
                        }),
                      ),
                      if (_showCustomUnit) ...[
                        const SizedBox(height: 8),
                        TextFormField(
                          controller: _customUnitCtrl,
                          decoration: const InputDecoration(
                            labelText: 'Custom Unit Type लिहा',
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(Icons.edit, size: 18),
                          ),
                          onChanged: (val) => setState(() { _selectedUnit = val.trim(); }),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: TextFormField(controller: _cmlCtrl, decoration: const InputDecoration(labelText: 'CML Number', border: OutlineInputBorder()))),
                const SizedBox(width: 12),
                Expanded(child: TextFormField(controller: _batchCtrl, decoration: const InputDecoration(labelText: 'Batch Number', border: OutlineInputBorder()))),
              ],
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _companyRateCtrl,
              decoration: const InputDecoration(labelText: 'Company Rate (Purchase) (Optional)', border: OutlineInputBorder(), prefixText: 'Rs. '),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _saleRateCtrl,
              decoration: const InputDecoration(labelText: 'Sale Rate (Excluding GST) (Optional)', border: OutlineInputBorder(), prefixText: 'Rs. '),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _gstCtrl,
              decoration: const InputDecoration(labelText: 'GST Percentage (e.g. 18) (Optional)', border: OutlineInputBorder(), suffixText: '%'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.orange,
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () async {
                if (_formKey.currentState!.validate()) {
                  double finalCompanyRate = double.tryParse(_companyRateCtrl.text.trim()) ?? 0.0;
                  double finalSaleRate = double.tryParse(_saleRateCtrl.text.trim()) ?? 0.0;
                  double finalGst = double.tryParse(_gstCtrl.text.trim()) ?? 0.0;

                  final p = ProductModel(
                    id: widget.product?.id,
                    name: _nameCtrl.text.trim(),
                    hsnCode: _hsnCtrl.text.trim(),
                    cmlNumber: _cmlCtrl.text.trim(),
                    batchNumber: _batchCtrl.text.trim(),
                    companyRate: finalCompanyRate,
                    saleRate: finalSaleRate,
                    gstPercentage: finalGst,
                    unitType: _selectedUnit,
                  );

                  if (widget.product == null) {
                    await _productRepo.insert(p);
                  } else {
                    await _productRepo.update(p);
                  }

                  if (mounted) Navigator.pop(context);
                }
              },
              child: const Text('Save Product Item', style: TextStyle(fontSize: 16, color: Colors.white, fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }
}
