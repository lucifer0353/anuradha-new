import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../data/models/customer_model.dart';
import '../../data/models/invoice_model.dart';
import '../../data/models/settings_model.dart';
import '../../data/models/product_model.dart';
import '../../data/repositories/customer_repository.dart';
import '../../data/repositories/invoice_repository.dart';
import '../../data/repositories/settings_repository.dart';
import '../../data/repositories/product_repository.dart';
import '../../services/pdf_service.dart';
import '../../services/draft_service.dart';
import '../customers/customer_form_screen.dart';
import '../products/product_form_screen.dart';

class InvoiceFormScreen extends StatefulWidget {
  const InvoiceFormScreen({super.key});
  @override
  State<InvoiceFormScreen> createState() => _InvoiceFormScreenState();
}

class _InvoiceFormScreenState extends State<InvoiceFormScreen> {
  CustomerModel? _selectedCustomer;
  final List<InvoiceItemModel> _items = [];
  String _paymentStatus = 'Paid';

  // Totals
  double _productTotal = 0.0;
  double _taxableAmount = 0.0;
  double _cgst = 0.0;
  double _sgst = 0.0;
  double _totalGst = 0.0;
  double _grandTotal = 0.0;
  double _roundOff = 0.0;
  double _finalAmount = 0.0;

  // Bill Discount
  bool _billDiscountIsPercent = true;
  final _billDiscountCtrl = TextEditingController(text: '0');
  double _billDiscountValue = 0.0;
  double _billDiscountAmt = 0.0;

  // Round Off
  bool _enableRoundOff = false;

  // Auto-save draft timer
  Timer? _draftTimer;

  @override
  void initState() {
    super.initState();
    _loadRoundOffSetting();
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkForDraft());
  }

  @override
  void dispose() {
    _draftTimer?.cancel();
    _billDiscountCtrl.dispose();
    super.dispose();
  }

  Future<void> _loadRoundOffSetting() async {
    final settings = await SettingsRepository().getSettings();
    if (mounted) setState(() { _enableRoundOff = settings.enableRoundOff; });
  }

  // Draft check on open
  Future<void> _checkForDraft() async {
    final has = await DraftService.hasDraft();
    if (!has || !mounted) return;

    final draft = await DraftService.loadDraft();
    if (draft == null) return;

    final updatedAt = draft['updatedAt'] as String;
    final dt = DateTime.tryParse(updatedAt);
    final timeStr = dt != null ? DateFormat('dd/MM/yyyy hh:mm a').format(dt) : updatedAt;

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Row(children: [
          Icon(Icons.drafts, color: Colors.orange),
          SizedBox(width: 8),
          Text('Draft Invoice सापडला!', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ]),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Last saved: $timeStr', style: const TextStyle(color: Colors.grey, fontSize: 12)),
            const SizedBox(height: 8),
            const Text('एक अर्धवट invoice draft आहे. सुरू ठेवायचा का?'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () async {
              Navigator.pop(ctx);
              await DraftService.deleteDraft();
            },
            child: const Text('Discard Draft', style: TextStyle(color: Colors.red)),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, foregroundColor: Colors.white),
            onPressed: () {
              Navigator.pop(ctx);
              _restoreDraft(draft);
            },
            child: const Text('Continue Draft'),
          ),
        ],
      ),
    );
  }

  void _restoreDraft(Map<String, dynamic> draft) {
    setState(() {
      _selectedCustomer = draft['customer'] as CustomerModel?;
      _items.clear();
      _items.addAll(draft['items'] as List<InvoiceItemModel>);
      _paymentStatus = draft['paymentStatus'] as String;
      _billDiscountIsPercent = draft['billDiscountIsPercent'] as bool;
      final pct = (draft['billDiscountPct'] as double);
      final amt = (draft['billDiscountAmt'] as double);
      _billDiscountValue = _billDiscountIsPercent ? pct : amt;
      _billDiscountCtrl.text = _billDiscountValue.toString();
    });
    _calculateTotals();
  }

  // Auto save draft — debounced
  void _scheduleDraftSave() {
    _draftTimer?.cancel();
    _draftTimer = Timer(const Duration(seconds: 2), () {
      _saveDraft();
    });
  }

  Future<void> _saveDraft() async {
    await DraftService.saveDraft(
      customer: _selectedCustomer,
      items: List.from(_items),
      paymentStatus: _paymentStatus,
      billDiscountPct: _billDiscountIsPercent ? _billDiscountValue : 0,
      billDiscountAmt: _billDiscountIsPercent ? 0 : _billDiscountValue,
      billDiscountIsPercent: _billDiscountIsPercent,
    );
  }

  // ===== CALCULATIONS =====
  void _calculateTotals() {
    double productTotal = 0.0;
    double totalGstFromItems = 0.0;
    double taxableFromItems = 0.0;

    for (var item in _items) {
      // Item level: discountedRate already set in item
      double itemTaxable = item.discountedRate * item.quantity;
      double itemGst = itemTaxable * (item.gstPercentage / 100);
      taxableFromItems += itemTaxable;
      totalGstFromItems += itemGst;
      productTotal += itemTaxable + itemGst; // item total with GST
    }

    // Bill Discount on taxable amount (before GST)
    double billDiscAmt = 0.0;
    if (_billDiscountIsPercent) {
      billDiscAmt = taxableFromItems * (_billDiscountValue / 100);
    } else {
      billDiscAmt = _billDiscountValue;
    }
    // Cap bill discount
    billDiscAmt = billDiscAmt.clamp(0, taxableFromItems);

    double taxableAfterDiscount = taxableFromItems - billDiscAmt;

    // Recalculate GST on discounted taxable
    double cgst = 0.0;
    double sgst = 0.0;
    if (taxableFromItems > 0) {
      double discountRatio = taxableAfterDiscount / taxableFromItems;
      cgst = (totalGstFromItems / 2) * discountRatio;
      sgst = (totalGstFromItems / 2) * discountRatio;
    }
    double totalGst = cgst + sgst;
    double grandTotal = taxableAfterDiscount + totalGst;

    // Round off
    double roundOff = 0.0;
    double finalAmount = grandTotal;
    if (_enableRoundOff) {
      double rounded = grandTotal.roundToDouble();
      roundOff = rounded - grandTotal;
      finalAmount = rounded;
    }

    setState(() {
      _productTotal = productTotal;
      _billDiscountAmt = billDiscAmt;
      _taxableAmount = taxableAfterDiscount;
      _cgst = cgst;
      _sgst = sgst;
      _totalGst = totalGst;
      _grandTotal = grandTotal;
      _roundOff = roundOff;
      _finalAmount = finalAmount;
    });

    _scheduleDraftSave();
  }

  // ===== ADD ITEM DIALOG =====
  void _showAddItemDialog() async {
    final productRepo = ProductRepository();
    List<ProductModel> allProducts = await productRepo.getAllProducts();
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Add Product', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
              IconButton(
                icon: const Icon(Icons.add_business, color: Colors.blueGrey, size: 28),
                onPressed: () async {
                  await Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductFormScreen()));
                  final updated = await productRepo.getAllProducts();
                  setDialogState(() { allProducts = updated; });
                },
              ),
            ],
          ),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: InputDecoration(
                    hintText: 'Search product...',
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    contentPadding: const EdgeInsets.symmetric(vertical: 8),
                  ),
                  onChanged: (value) async {
                    final filtered = await productRepo.searchProducts(value);
                    setDialogState(() { allProducts = filtered; });
                  },
                ),
                const SizedBox(height: 12),
                Expanded(
                  child: allProducts.isEmpty
                    ? const Center(child: Text('No products found.'))
                    : ListView.builder(
                        itemCount: allProducts.length,
                        itemBuilder: (_, i) {
                          final prod = allProducts[i];
                          return ListTile(
                            title: Text(prod.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                            subtitle: Text('Rate: Rs. ${prod.saleRate} | GST: ${prod.gstPercentage}%'),
                            trailing: const Icon(Icons.add_circle_outline, color: Colors.green),
                            onTap: () { Navigator.pop(context); _showItemDetailsDialog(prod); },
                          );
                        },
                      ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // Item details dialog — full edit form
  void _showItemDetailsDialog(ProductModel prod, {int? editIndex}) {
    final existing = editIndex != null ? _items[editIndex] : null;
    final nameCtrl = TextEditingController(text: existing?.productName ?? prod.name);
    final hsnCtrl  = TextEditingController(text: existing?.hsnCode ?? prod.hsnCode);
    final cmlCtrl  = TextEditingController(text: existing?.cmlNumber ?? prod.cmlNumber);
    final batchCtrl= TextEditingController(text: existing?.batchNumber ?? prod.batchNumber);
    final qtyCtrl  = TextEditingController(text: existing?.quantity.toString() ?? '1');
    final compRateCtrl = TextEditingController(text: (existing?.companyRate ?? prod.companyRate).toString());
    final saleRateCtrl = TextEditingController(text: (existing?.saleRate ?? prod.saleRate).toString());
    final gstCtrl  = TextEditingController(text: (existing?.gstPercentage ?? prod.gstPercentage).toString());
    final discCtrl = TextEditingController(
      text: existing != null
        ? (existing.discountPct > 0 ? existing.discountPct.toString() : existing.discountAmt.toString())
        : '0');
    bool discIsPercent = existing != null ? (existing.discountPct > 0 || existing.discountAmt == 0) : true;
    String selectedUnit = existing?.unit ?? prod.unitType;
    double saleRate = existing?.saleRate ?? prod.saleRate;
    double gstPct = existing?.gstPercentage ?? prod.gstPercentage;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) {
          double qty = double.tryParse(qtyCtrl.text) ?? 1;
          double disc = double.tryParse(discCtrl.text) ?? 0;
          double discAmt = discIsPercent ? saleRate * (disc / 100) : disc;
          discAmt = discAmt.clamp(0, saleRate);
          double discountedRate = saleRate - discAmt;
          double taxable = discountedRate * qty;
          double gstAmt = taxable * (gstPct / 100);
          double total = taxable + gstAmt;

          return AlertDialog(
            title: Text(editIndex != null ? 'Edit Item' : prod.name,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Product Name
                  TextFormField(
                    controller: nameCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Product Name',
                      prefixIcon: Icon(Icons.inventory_2),
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // HSN / SAC
                  TextFormField(
                    controller: hsnCtrl,
                    decoration: const InputDecoration(
                      labelText: 'HSN/SAC Code',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 10),
                  // CML + Batch in a row
                  Row(children: [
                    Expanded(child: TextFormField(
                      controller: cmlCtrl,
                      decoration: const InputDecoration(labelText: 'CML No.', border: OutlineInputBorder()),
                    )),
                    const SizedBox(width: 8),
                    Expanded(child: TextFormField(
                      controller: batchCtrl,
                      decoration: const InputDecoration(labelText: 'Batch No.', border: OutlineInputBorder()),
                    )),
                  ]),
                  const SizedBox(height: 10),
                  // Quantity + Unit
                  Row(children: [
                    Expanded(flex: 2, child: TextFormField(
                      controller: qtyCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(
                        labelText: 'Quantity',
                        border: OutlineInputBorder(),
                      ),
                      onChanged: (_) => setS(() {}),
                    )),
                    const SizedBox(width: 8),
                    Expanded(flex: 3, child: DropdownButtonFormField<String>(
                      value: selectedUnit,
                      decoration: const InputDecoration(labelText: 'Unit', border: OutlineInputBorder()),
                      isExpanded: true,
                      items: ['Piece', 'Mtr', 'Kg', 'Nos', 'Box', 'Set', 'Ltr', 'Bag', 'Bundle', 'Custom']
                        .map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(),
                      onChanged: (v) => setS(() { selectedUnit = v!; }),
                    )),
                  ]),
                  const SizedBox(height: 10),
                  // Company Rate + Sale Rate
                  Row(children: [
                    Expanded(child: TextFormField(
                      controller: compRateCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: 'Comp. Rate', border: OutlineInputBorder()),
                      onChanged: (_) => setS(() {}),
                    )),
                    const SizedBox(width: 8),
                    Expanded(child: TextFormField(
                      controller: saleRateCtrl,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      decoration: const InputDecoration(labelText: 'Sale Rate', border: OutlineInputBorder()),
                      onChanged: (v) { saleRate = double.tryParse(v) ?? saleRate; setS(() {}); },
                    )),
                  ]),
                  const SizedBox(height: 10),
                  // GST %
                  TextFormField(
                    controller: gstCtrl,
                    keyboardType: const TextInputType.numberWithOptions(decimal: true),
                    decoration: const InputDecoration(
                      labelText: 'GST %',
                      border: OutlineInputBorder(),
                    ),
                    onChanged: (v) { gstPct = double.tryParse(v) ?? gstPct; setS(() {}); },
                  ),
                  const SizedBox(height: 12),

                  // Discount section
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.orange[50],
                      border: Border.all(color: Colors.orange[200]!),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Item Discount (Optional)',
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.orange)),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: discCtrl,
                                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                                decoration: InputDecoration(
                                  labelText: discIsPercent ? 'Discount %' : 'Discount ₹',
                                  border: const OutlineInputBorder(),
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                                ),
                                onChanged: (_) => setS(() {}),
                              ),
                            ),
                            const SizedBox(width: 8),
                            ToggleButtons(
                              isSelected: [discIsPercent, !discIsPercent],
                              onPressed: (i) => setS(() { discIsPercent = i == 0; discCtrl.text = '0'; }),
                              borderRadius: BorderRadius.circular(6),
                              selectedColor: Colors.white,
                              fillColor: Colors.orange,
                              constraints: const BoxConstraints(minWidth: 44, minHeight: 40),
                              children: const [Text('%'), Text('₹')],
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Live calculation preview
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: Colors.green[50],
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: Colors.green[200]!),
                    ),
                    child: Column(
                      children: [
                        _calcRow('Rate', 'Rs. ${saleRate.toStringAsFixed(2)}'),
                        if (discAmt > 0) _calcRow('Discount', '- Rs. ${discAmt.toStringAsFixed(2)}', color: Colors.red),
                        if (discAmt > 0) _calcRow('After Discount', 'Rs. ${discountedRate.toStringAsFixed(2)}'),
                        _calcRow('Qty x Rate', 'Rs. ${taxable.toStringAsFixed(2)}'),
                        _calcRow('GST ${gstPct}%', 'Rs. ${gstAmt.toStringAsFixed(2)}'),
                        const Divider(),
                        _calcRow('Total', 'Rs. ${total.toStringAsFixed(2)}', bold: true),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                onPressed: () {
                  final q = double.tryParse(qtyCtrl.text) ?? 1;
                  final d = double.tryParse(discCtrl.text) ?? 0;
                  final sr = double.tryParse(saleRateCtrl.text) ?? saleRate;
                  final gp = double.tryParse(gstCtrl.text) ?? gstPct;
                  final cr = double.tryParse(compRateCtrl.text) ?? 0;
                  double dAmt = discIsPercent ? sr * (d / 100) : d;
                  dAmt = dAmt.clamp(0, sr);
                  final dRate = sr - dAmt;
                  final tax = dRate * q;
                  final gstAmt = tax * (gp / 100);

                  final item = InvoiceItemModel(
                    productName: nameCtrl.text.trim().isNotEmpty ? nameCtrl.text.trim() : prod.name,
                    hsnCode: hsnCtrl.text.trim(),
                    cmlNumber: cmlCtrl.text.trim(),
                    batchNumber: batchCtrl.text.trim(),
                    quantity: q,
                    unit: selectedUnit,
                    companyRate: cr,
                    saleRate: sr,
                    discountPct: discIsPercent ? d : 0,
                    discountAmt: discIsPercent ? 0 : d,
                    discountedRate: dRate,
                    gstPercentage: gp,
                    amount: tax + gstAmt,
                  );

                  Navigator.pop(ctx);
                  setState(() {
                    if (editIndex != null) {
                      _items[editIndex] = item;
                    } else {
                      _items.add(item);
                    }
                  });
                  _calculateTotals();
                },
                child: Text(editIndex != null ? 'Update Item' : 'Add Item'),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _calcRow(String label, String value, {bool bold = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontSize: 12, fontWeight: bold ? FontWeight.bold : FontWeight.normal)),
          Text(value, style: TextStyle(fontSize: 12, fontWeight: bold ? FontWeight.bold : FontWeight.normal,
            color: color ?? (bold ? Colors.green[800] : Colors.black))),
        ],
      ),
    );
  }

  // ===== GENERATE PDF =====
  Future<void> _generateAndSavePdf() async {
    if (_selectedCustomer == null || _items.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a customer and add at least one product.'),
          backgroundColor: Colors.red));
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Colors.green),
            SizedBox(height: 16),
            Material(color: Colors.transparent,
              child: Text('Generating Invoice PDF...', style: TextStyle(color: Colors.white, fontSize: 16))),
          ],
        ),
      ),
    );

    try {
      final settingsRepo = SettingsRepository();
      final settings = await settingsRepo.getSettings();
      final now = DateTime.now();

      String invoiceNum = settings.invoiceFormat.trim().isEmpty
        ? "INV-${now.millisecondsSinceEpoch}"
        : settings.invoiceFormat.trim();

      // Auto increment invoice number
      try {
        RegExp regExp = RegExp(r'(\d+)$');
        Match? match = regExp.firstMatch(settings.invoiceFormat.trim());
        if (match != null) {
          String last = match.group(0)!;
          int next = int.parse(last) + 1;
          String nextStr = next.toString().padLeft(last.length, '0');
          String nextFormat = settings.invoiceFormat.trim().substring(0, match.start) + nextStr;
          await settingsRepo.updateSettings(SettingsModel(
            id: settings.id, address: settings.address, authorizedDealer: settings.authorizedDealer,
            gstin: settings.gstin, mobile1: settings.mobile1, mobile2: settings.mobile2,
            email1: settings.email1, email2: settings.email2, logoPath: settings.logoPath,
            ownerName1: settings.ownerName1, designation1: settings.designation1, sigPath1: settings.sigPath1,
            ownerName2: '', designation2: '', sigPath2: '', qrPath: settings.qrPath,
            locationQrPath: settings.locationQrPath,
            bankName: settings.bankName, accName: settings.accName, accNumber: settings.accNumber,
            ifscCode: settings.ifscCode, upiId: settings.upiId, invoiceFormat: nextFormat,
            invoiceTitle: settings.invoiceTitle,
            terms: settings.terms, declaration: settings.declaration, language: settings.language, enableRoundOff: settings.enableRoundOff,
          ));
        }
      } catch (_) {}

      final inv = InvoiceModel(
        invoiceNumber: invoiceNum,
        date: DateFormat('dd-MM-yyyy').format(now),
        time: DateFormat('hh:mm a').format(now),
        customerId: _selectedCustomer!.id!,
        customerName: _selectedCustomer!.name,
        customerMobile: _selectedCustomer!.mobile,
        customerGstin: _selectedCustomer!.gstin,
        customerGat: _selectedCustomer!.gatNumber,
        customerArea: _selectedCustomer!.area,
        customerCrop: _selectedCustomer!.crop,
        customerRemarks: _selectedCustomer!.remarks,
        customerAddress: _selectedCustomer!.address,
        customerState: _selectedCustomer!.state,
        customerDistrict: _selectedCustomer!.district,
        customerSubDistrict: _selectedCustomer!.subDistrict,
        customerStateCode: _selectedCustomer!.stateCode,
        customerAreaUnit: _selectedCustomer!.areaUnit,
        productTotal: _productTotal,
        billDiscount: _billDiscountAmt,
        billDiscountPct: _billDiscountIsPercent ? _billDiscountValue : 0,
        taxableAmount: _taxableAmount,
        cgst: _cgst,
        sgst: _sgst,
        totalGst: _totalGst,
        grandTotal: _grandTotal,
        roundOff: _roundOff,
        finalAmount: _finalAmount,
        amountInWords: _convertToWords(_finalAmount),
        paymentStatus: _paymentStatus,
        items: _items,
      );

      await InvoiceRepository().createInvoice(inv);

      // Delete draft after successful save
      await DraftService.deleteDraft();

      final pdfFile = await AMSInvoicePdfEngine.generateInvoicePdf(inv, settings);

      if (mounted) Navigator.pop(context);
      if (mounted) await AMSInvoicePdfEngine.showPdfOptions(context, pdfFile, invoiceNum, inv, settings);
      if (mounted) Navigator.pop(context);

    } catch (e) {
      if (mounted) Navigator.pop(context);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: ${e.toString()}'), backgroundColor: Colors.red,
          duration: const Duration(seconds: 5)));
    }
  }

  // ===== Amount in Words =====
  String _convertToWords(double amount) {
    final int rupees = amount.floor();
    final int paise = ((amount - rupees) * 100).round();
    String words = _numToWords(rupees);
    if (paise > 0) return "Rupees $words and ${_numToWords(paise)} Paise Only";
    return "Rupees $words Only";
  }

  String _numToWords(int n) {
    if (n == 0) return "Zero";
    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
    String words = '';
    if (n >= 10000000) { words += '${_numToWords(n ~/ 10000000)} Crore '; n %= 10000000; }
    if (n >= 100000) { words += '${_numToWords(n ~/ 100000)} Lakh '; n %= 100000; }
    if (n >= 1000) { words += '${_numToWords(n ~/ 1000)} Thousand '; n %= 1000; }
    if (n >= 100) { words += '${ones[n ~/ 100]} Hundred '; n %= 100; }
    if (n >= 20) { words += '${tens[n ~/ 10]} '; n %= 10; }
    if (n > 0) { words += '${ones[n]} '; }
    return words.trim();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('New GST Invoice',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          // Customer Selection
          Card(
            color: Colors.red[50],
            child: ListTile(
              leading: const Icon(Icons.person, color: Colors.green),
              title: Text(
                _selectedCustomer == null ? 'Select Customer *' : _selectedCustomer!.name,
                style: TextStyle(fontWeight: FontWeight.bold,
                  color: _selectedCustomer == null ? Colors.red : Colors.black),
              ),
              subtitle: _selectedCustomer != null
                ? Text('📱 ${_selectedCustomer!.mobile}', style: const TextStyle(fontSize: 12))
                : null,
              onTap: () async {
                final customerRepo = CustomerRepository();
                List<CustomerModel> allCustomers = await customerRepo.searchCustomers('');
                if (!mounted) return;
                final choice = await showDialog<CustomerModel>(
                  context: context,
                  builder: (context) => StatefulBuilder(
                    builder: (context, setS) => AlertDialog(
                      title: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Select Customer'),
                          IconButton(
                            icon: const Icon(Icons.person_add, color: Colors.green),
                            onPressed: () async {
                              await Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerFormScreen()));
                              final updated = await customerRepo.searchCustomers('');
                              setS(() { allCustomers = updated; });
                            },
                          ),
                        ],
                      ),
                      content: SizedBox(
                        width: double.maxFinite,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            TextField(
                              decoration: const InputDecoration(hintText: 'Search...', prefixIcon: Icon(Icons.search), border: OutlineInputBorder()),
                              onChanged: (v) async {
                                final f = await customerRepo.searchCustomers(v);
                                setS(() { allCustomers = f; });
                              },
                            ),
                            const SizedBox(height: 12),
                            Expanded(
                              child: allCustomers.isEmpty
                                ? const Center(child: Text('No customers'))
                                : ListView.builder(
                                    itemCount: allCustomers.length,
                                    itemBuilder: (_, i) => ListTile(
                                      title: Text(allCustomers[i].name),
                                      subtitle: Text(allCustomers[i].mobile),
                                      onTap: () => Navigator.pop(context, allCustomers[i]),
                                    ),
                                  ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
                if (choice != null) {
                  setState(() { _selectedCustomer = choice; });
                  _scheduleDraftSave();
                }
              },
            ),
          ),
          const SizedBox(height: 16),

          // Products Section
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Invoice Items', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
                onPressed: _showAddItemDialog,
                icon: const Icon(Icons.add),
                label: const Text('Add Item'),
              ),
            ],
          ),
          const Divider(),

          if (_items.isEmpty)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24.0),
              child: Center(child: Text('No products added.')),
            )
          else
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: _items.length,
              itemBuilder: (_, i) {
                final item = _items[i];
                final hasDiscount = item.discountPct > 0 || item.discountAmt > 0;
                return Card(
                  child: ListTile(
                    title: Text(item.productName, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Qty: ${item.quantity} ${item.unit} x Rs. ${item.saleRate.toStringAsFixed(2)}'),
                        if (hasDiscount)
                          Text(
                            item.discountPct > 0
                              ? 'Discount: ${item.discountPct}% → Rs. ${item.discountedRate.toStringAsFixed(2)}'
                              : 'Discount: ₹${item.discountAmt.toStringAsFixed(2)} → Rs. ${item.discountedRate.toStringAsFixed(2)}',
                            style: const TextStyle(color: Colors.orange, fontSize: 11),
                          ),
                        Text('GST: ${item.gstPercentage}% | Amount: Rs. ${item.amount.toStringAsFixed(2)}'),
                      ],
                    ),
                    isThreeLine: true,
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: const Icon(Icons.edit, color: Colors.blue),
                          onPressed: () {
                            final prod = ProductModel(
                              name: item.productName, hsnCode: item.hsnCode,
                              cmlNumber: item.cmlNumber, batchNumber: item.batchNumber,
                              companyRate: item.companyRate, saleRate: item.saleRate,
                              gstPercentage: item.gstPercentage, unitType: item.unit,
                            );
                            _showItemDetailsDialog(prod, editIndex: i);
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.red),
                          onPressed: () {
                            setState(() { _items.removeAt(i); });
                            _calculateTotals();
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),

          const SizedBox(height: 12),

          // Payment Status
          DropdownButtonFormField<String>(
            value: _paymentStatus,
            decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Payment Status'),
            items: const [
              DropdownMenuItem(value: 'Paid', child: Text('Paid')),
              DropdownMenuItem(value: 'Unpaid', child: Text('Unpaid')),
            ],
            onChanged: (v) { setState(() { _paymentStatus = v!; }); _scheduleDraftSave(); },
          ),
          const SizedBox(height: 16),

          // Bill Discount
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.orange[50],
              border: Border.all(color: Colors.orange[200]!),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Overall Bill Discount', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.orange)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _billDiscountCtrl,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: InputDecoration(
                          labelText: _billDiscountIsPercent ? 'Discount %' : 'Discount ₹',
                          border: const OutlineInputBorder(),
                        ),
                        onChanged: (v) {
                          _billDiscountValue = double.tryParse(v) ?? 0;
                          _calculateTotals();
                        },
                      ),
                    ),
                    const SizedBox(width: 10),
                    ToggleButtons(
                      isSelected: [_billDiscountIsPercent, !_billDiscountIsPercent],
                      onPressed: (i) {
                        setState(() {
                          _billDiscountIsPercent = i == 0;
                          _billDiscountCtrl.text = '0';
                          _billDiscountValue = 0;
                        });
                        _calculateTotals();
                      },
                      borderRadius: BorderRadius.circular(6),
                      selectedColor: Colors.white,
                      fillColor: Colors.orange,
                      constraints: const BoxConstraints(minWidth: 48, minHeight: 48),
                      children: const [Text('%', style: TextStyle(fontWeight: FontWeight.bold)),
                        Text('₹', style: TextStyle(fontWeight: FontWeight.bold))],
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          // Totals Summary
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.grey[100], borderRadius: BorderRadius.circular(8)),
            child: Column(
              children: [
                if (_billDiscountAmt > 0) ...[
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Product Total:'),
                    Text('Rs. ${(_taxableAmount + _billDiscountAmt).toStringAsFixed(2)}'),
                  ]),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Text('Bill Discount${_billDiscountIsPercent ? " (${_billDiscountValue.toStringAsFixed(1)}%)" : ""}:',
                      style: const TextStyle(color: Colors.red)),
                    Text('- Rs. ${_billDiscountAmt.toStringAsFixed(2)}', style: const TextStyle(color: Colors.red)),
                  ]),
                ],
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Taxable Amount:'),
                  Text('Rs. ${_taxableAmount.toStringAsFixed(2)}'),
                ]),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('CGST + SGST:'),
                  Text('Rs. ${_totalGst.toStringAsFixed(2)}'),
                ]),
                const Divider(),
                Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                  const Text('Grand Total:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  Text('Rs. ${_grandTotal.toStringAsFixed(2)}',
                    style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                ]),
                const SizedBox(height: 8),
                // Round Off Toggle
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: _enableRoundOff ? Colors.green[50] : Colors.white,
                    border: Border.all(color: _enableRoundOff ? Colors.green[300]! : Colors.grey[300]!),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        const Text('Round Off', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                        Text(
                          _enableRoundOff ? 'Amount nearest rupee ला round होईल' : 'Exact amount दिसेल',
                          style: TextStyle(fontSize: 10, color: _enableRoundOff ? Colors.green[700] : Colors.grey),
                        ),
                      ]),
                      Switch(
                        value: _enableRoundOff,
                        activeColor: Colors.green,
                        onChanged: (v) {
                          setState(() { _enableRoundOff = v; });
                          _calculateTotals();
                        },
                      ),
                    ],
                  ),
                ),
                if (_enableRoundOff && _roundOff != 0) ...[
                  const SizedBox(height: 6),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Round Off:'),
                    Text('${_roundOff >= 0 ? '+' : ''}Rs. ${_roundOff.toStringAsFixed(2)}',
                      style: TextStyle(color: _roundOff >= 0 ? Colors.green : Colors.red)),
                  ]),
                  const Divider(),
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    const Text('Final Payable:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.green)),
                    Text('Rs. ${_finalAmount.toStringAsFixed(2)}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.green)),
                  ]),
                ],
              ],
            ),
          ),
          const SizedBox(height: 20),

          // Generate Button
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.green,
              minimumSize: const Size.fromHeight(55),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: _generateAndSavePdf,
            icon: const Icon(Icons.picture_as_pdf, color: Colors.white),
            label: const Text('Generate & Save Invoice PDF',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
