import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../data/models/invoice_model.dart';
import '../../data/repositories/invoice_repository.dart';
import '../../data/repositories/settings_repository.dart';
import '../../services/pdf_service.dart';

class InvoiceHistoryScreen extends StatefulWidget {
  const InvoiceHistoryScreen({super.key});
  @override
  State<InvoiceHistoryScreen> createState() => _InvoiceHistoryScreenState();
}

class _InvoiceHistoryScreenState extends State<InvoiceHistoryScreen> {
  final _repo = InvoiceRepository();
  List<InvoiceModel> _allHistory = [];
  List<InvoiceModel> _filteredHistory = [];
  bool _isLoading = true;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadHistory();
    _searchCtrl.addListener(_onSearch);
  }

  @override
  void dispose() {
    _searchCtrl.removeListener(_onSearch);
    _searchCtrl.dispose();
    super.dispose();
  }

  void _loadHistory() async {
    setState(() { _isLoading = true; });
    final list = await _repo.getInvoiceHistory();
    setState(() {
      _allHistory = list;
      _filteredHistory = list;
      _isLoading = false;
    });
  }

  void _onSearch() {
    final query = _searchCtrl.text.trim().toLowerCase();
    setState(() {
      if (query.isEmpty) {
        _filteredHistory = _allHistory;
      } else {
        _filteredHistory = _allHistory.where((inv) =>
          inv.invoiceNumber.toLowerCase().contains(query) ||
          inv.customerName.toLowerCase().contains(query) ||
          inv.customerMobile.toLowerCase().contains(query) ||
          inv.date.toLowerCase().contains(query) ||
          inv.paymentStatus.toLowerCase().contains(query) ||
          inv.grandTotal.toString().contains(query)
        ).toList();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Invoice History', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blueGrey,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 6),
            child: TextField(
              controller: _searchCtrl,
              decoration: InputDecoration(
                hintText: 'Search by name, invoice no, date, amount...',
                prefixIcon: const Icon(Icons.search, color: Colors.blueGrey),
                suffixIcon: _searchCtrl.text.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () { _searchCtrl.clear(); },
                    )
                  : null,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                contentPadding: const EdgeInsets.symmetric(vertical: 10),
              ),
            ),
          ),

          // Count
          if (!_isLoading)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
              child: Row(
                children: [
                  Text(
                    _searchCtrl.text.isNotEmpty
                      ? '${_filteredHistory.length} results found'
                      : 'Total: ${_allHistory.length} invoices',
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ],
              ),
            ),

          // List
          Expanded(
            child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _filteredHistory.isEmpty
                ? Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.search_off, size: 48, color: Colors.grey),
                        const SizedBox(height: 8),
                        Text(
                          _searchCtrl.text.isNotEmpty ? 'No results found' : 'No invoices yet',
                          style: const TextStyle(color: Colors.grey, fontSize: 16),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: _filteredHistory.length,
                    itemBuilder: (_, i) {
                      final inv = _filteredHistory[i];
                      final isPaid = inv.paymentStatus.toLowerCase() == 'paid';
                      return Card(
                        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: isPaid ? Colors.green[50] : Colors.red[50],
                            child: Icon(Icons.description,
                              color: isPaid ? Colors.green : Colors.red),
                          ),
                          title: Text('${inv.invoiceNumber}',
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('👤 ${inv.customerName}', style: const TextStyle(fontSize: 12)),
                              Text('📅 ${inv.date} | 💰 Rs. ${inv.grandTotal.toStringAsFixed(2)}',
                                style: const TextStyle(fontSize: 11)),
                              Container(
                                margin: const EdgeInsets.only(top: 3),
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                                decoration: BoxDecoration(
                                  color: isPaid ? Colors.green[100] : Colors.red[100],
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(inv.paymentStatus,
                                  style: TextStyle(
                                    fontSize: 10, fontWeight: FontWeight.bold,
                                    color: isPaid ? Colors.green[800] : Colors.red[800])),
                              ),
                            ],
                          ),
                          isThreeLine: true,
                          trailing: PopupMenuButton<String>(
                            icon: const Icon(Icons.more_vert),
                            onSelected: (value) async {
                              if (value == 'view') {
                                try {
                                  final settings = await SettingsRepository().getSettings();
                                  final pdfFile = await AMSInvoicePdfEngine.generateInvoicePdf(inv, settings);
                                  if (context.mounted) {
                                    await AMSInvoicePdfEngine.showPdfOptions(context, pdfFile, inv.invoiceNumber, inv, settings);
                                  }
                                } catch (e) {
                                  if (context.mounted) {
                                    ScaffoldMessenger.of(context).showSnackBar(
                                      SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
                                  }
                                }
                              } else if (value == 'delete') {
                                final confirm = await showDialog<bool>(
                                  context: context,
                                  builder: (_) => AlertDialog(
                                    title: const Text('Delete Invoice?'),
                                    content: Text('Invoice ${inv.invoiceNumber} delete करायची?'),
                                    actions: [
                                      TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
                                      TextButton(
                                        onPressed: () => Navigator.pop(context, true),
                                        child: const Text('Delete', style: TextStyle(color: Colors.red)),
                                      ),
                                    ],
                                  ),
                                );
                                if (confirm == true && inv.id != null) {
                                  await _repo.deleteInvoice(inv.id!);
                                  _loadHistory();
                                }
                              }
                            },
                            itemBuilder: (_) => [
                              const PopupMenuItem(value: 'view', child: Row(
                                children: [Icon(Icons.picture_as_pdf, color: Colors.green), SizedBox(width: 8), Text('View / Share PDF')],
                              )),
                              const PopupMenuItem(value: 'delete', child: Row(
                                children: [Icon(Icons.delete_outline, color: Colors.red), SizedBox(width: 8), Text('Delete')],
                              )),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
