import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../data/models/country_code_model.dart';

class PhoneFieldWidget extends StatefulWidget {
  final TextEditingController controller;
  final String label;
  final String? initialCountryCode;
  final bool isRequired;
  final Function(String fullNumber)? onChanged;

  const PhoneFieldWidget({
    super.key,
    required this.controller,
    this.label = 'Mobile Number',
    this.initialCountryCode = '+91',
    this.isRequired = false,
    this.onChanged,
  });

  @override
  State<PhoneFieldWidget> createState() => _PhoneFieldWidgetState();
}

class _PhoneFieldWidgetState extends State<PhoneFieldWidget> {
  late CountryCode _selectedCountry;
  String? _errorText;

  @override
  void initState() {
    super.initState();
    _selectedCountry = kCountryCodes.firstWhere(
      (c) => c.code == widget.initialCountryCode,
      orElse: () => kCountryCodes.first, // Default: India
    );
  }

  void _validate(String value) {
    if (!mounted) return;
    setState(() {
      if (value.isEmpty) {
        _errorText = widget.isRequired ? 'Mobile number आवश्यक आहे' : null;
      } else if (value.length != _selectedCountry.digits) {
        _errorText = '${_selectedCountry.name} साठी ${_selectedCountry.digits} digits आवश्यक आहेत (सध्या: ${value.length})';
      } else {
        _errorText = null;
      }
    });
    widget.onChanged?.call('${_selectedCountry.code} ${widget.controller.text}');
  }

  void _showCountryPicker() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) {
        List<CountryCode> filtered = List.from(kCountryCodes);
        return StatefulBuilder(
          builder: (ctx, setS) => DraggableScrollableSheet(
            initialChildSize: 0.6,
            maxChildSize: 0.9,
            minChildSize: 0.4,
            expand: false,
            builder: (_, scrollCtrl) => Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      const Text('Country Code निवडा',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      TextField(
                        decoration: InputDecoration(
                          hintText: 'Country शोधा...',
                          prefixIcon: const Icon(Icons.search),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                          contentPadding: const EdgeInsets.symmetric(vertical: 8),
                        ),
                        onChanged: (q) {
                          setS(() {
                            filtered = kCountryCodes.where((c) =>
                              c.name.toLowerCase().contains(q.toLowerCase()) ||
                              c.code.contains(q)
                            ).toList();
                          });
                        },
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: ListView.builder(
                    controller: scrollCtrl,
                    itemCount: filtered.length,
                    itemBuilder: (_, i) {
                      final country = filtered[i];
                      final isSelected = country.code == _selectedCountry.code &&
                                         country.name == _selectedCountry.name;
                      return ListTile(
                        leading: Text(country.flag, style: const TextStyle(fontSize: 24)),
                        title: Text(country.name, style: const TextStyle(fontWeight: FontWeight.w500)),
                        subtitle: Text('${country.code} · ${country.digits} digits'),
                        trailing: isSelected ? const Icon(Icons.check_circle, color: Colors.green) : null,
                        selected: isSelected,
                        selectedTileColor: Colors.green[50],
                        onTap: () {
                          setState(() { _selectedCountry = country; });
                          _validate(widget.controller.text);
                          Navigator.pop(ctx);
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  // Full phone number with country code
  String get fullNumber => '${_selectedCountry.code} ${widget.controller.text}';

  // Validation for form
  String? validate() {
    final v = widget.controller.text.trim();
    if (v.isEmpty && widget.isRequired) return 'Mobile number आवश्यक आहे';
    if (v.isNotEmpty && v.length != _selectedCountry.digits) {
      return '${_selectedCountry.name} साठी ${_selectedCountry.digits} digits हवेत';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Country code selector button
            GestureDetector(
              onTap: _showCountryPicker,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
                decoration: BoxDecoration(
                  border: Border.all(color: _errorText != null ? Colors.red : Colors.grey[400]!),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(4),
                    bottomLeft: Radius.circular(4),
                  ),
                  color: Colors.grey[50],
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_selectedCountry.flag, style: const TextStyle(fontSize: 18)),
                    const SizedBox(width: 4),
                    Text(_selectedCountry.code,
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    const Icon(Icons.arrow_drop_down, size: 18),
                  ],
                ),
              ),
            ),
            // Phone number input
            Expanded(
              child: TextFormField(
                controller: widget.controller,
                keyboardType: TextInputType.phone,
                inputFormatters: [
                  FilteringTextInputFormatter.digitsOnly,
                  LengthLimitingTextInputFormatter(_selectedCountry.digits),
                ],
                decoration: InputDecoration(
                  labelText: widget.label,
                  errorText: null, // We handle error below
                  border: const OutlineInputBorder(
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(4),
                      bottomRight: Radius.circular(4),
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderSide: BorderSide(color: _errorText != null ? Colors.red : Colors.grey[400]!),
                    borderRadius: const BorderRadius.only(
                      topRight: Radius.circular(4),
                      bottomRight: Radius.circular(4),
                    ),
                  ),
                  suffixIcon: widget.controller.text.isNotEmpty &&
                    widget.controller.text.length == _selectedCountry.digits
                    ? const Icon(Icons.check_circle, color: Colors.green, size: 20)
                    : null,
                  hintText: '${'0' * _selectedCountry.digits} (${_selectedCountry.digits} digits)',
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
                ),
                onChanged: _validate,
                validator: (_) => validate(),
              ),
            ),
          ],
        ),
        // Error text
        if (_errorText != null)
          Padding(
            padding: const EdgeInsets.only(left: 4, top: 4),
            child: Text(_errorText!,
              style: const TextStyle(color: Colors.red, fontSize: 11)),
          ),
        // Digit counter
        if (widget.controller.text.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(left: 4, top: 2),
            child: Text(
              '${widget.controller.text.length}/${_selectedCountry.digits} digits',
              style: TextStyle(
                fontSize: 11,
                color: widget.controller.text.length == _selectedCountry.digits
                  ? Colors.green : Colors.orange,
              ),
            ),
          ),
      ],
    );
  }
}
