import 'dart:io';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../l10n/app_localizations.dart';
import '../../data/repositories/settings_repository.dart';
import '../../services/permission_service.dart';
import '../widgets/custom_widgets.dart';
import '../customers/customer_list_screen.dart';
import '../products/product_list_screen.dart';
import '../invoices/invoice_form_screen.dart';
import '../invoices/invoice_history_screen.dart';
import '../settings/settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> with WidgetsBindingObserver {
  Locale _currentLocale = const Locale('en');

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _loadLanguage();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkAndRequestPermissions();
    });
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // Settings वरून परत आल्यावर check — permission दिली असेल तर mark करा
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) async {
    if (state == AppLifecycleState.resumed) {
      if (Platform.isAndroid) {
        final sdkInt = await _getAndroidSdk();
        if (sdkInt >= 30) {
          final granted = await Permission.manageExternalStorage.isGranted;
          if (granted) {
            await PermissionService.markPermissionGranted();
          }
        }
      }
    }
  }

  Future<int> _getAndroidSdk() async {
    try {
      final result = await Process.run('getprop', ['ro.build.version.sdk']);
      return int.tryParse(result.stdout.toString().trim()) ?? 26;
    } catch (_) { return 26; }
  }

  Future<void> _checkAndRequestPermissions() async {
    if (!Platform.isAndroid || !mounted) return;
    try {
      final sdkInt = await _getAndroidSdk();

      // Basic storage/media permissions
      if (sdkInt >= 33) {
        final photos = await Permission.photos.status;
        if (!photos.isGranted) {
          await [Permission.photos, Permission.videos, Permission.audio].request();
        }
      } else if (sdkInt >= 23) {
        final storage = await Permission.storage.status;
        if (!storage.isGranted) await Permission.storage.request();
      }

      // All Files Access (Android 11+)
      // जेव्हा permission नसेल तेव्हाच dialog दाखवायचा
      // पण रोज नाही — एकदा granted झाली की mark करतो
      if (sdkInt >= 30) {
        final isGranted = await Permission.manageExternalStorage.isGranted;

        if (isGranted) {
          // Permission आहे — mark करा
          await PermissionService.markPermissionGranted();
        } else {
          // Permission नाही — dialog दाखवा
          if (mounted) await _showAllFilesDialog();
        }
      }
    } catch (_) {}
  }

  Future<void> _showAllFilesDialog() async {
    if (!mounted) return;
    await showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.folder_open, color: Colors.orange, size: 28),
            SizedBox(width: 8),
            Expanded(child: Text('Storage Permission आवश्यक',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold))),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('PDF Bills आणि Backup files save करण्यासाठी "All Files Access" permission द्यावी लागेल.'),
            SizedBox(height: 14),
            Text('Steps:', style: TextStyle(fontWeight: FontWeight.bold)),
            SizedBox(height: 6),
            Text('1. "Settings उघडा" बटण दाबा'),
            Text('2. "Allow access to all files" ON करा'),
            Text('3. मागे या — app चालू होईल ✅'),
            SizedBox(height: 10),
            Text('⚠️ ही permission दिल्याशिवाय PDF save होणार नाही.',
              style: TextStyle(color: Colors.red, fontSize: 11)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('नंतर देतो', style: TextStyle(color: Colors.grey)),
          ),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, foregroundColor: Colors.white),
            onPressed: () async {
              Navigator.pop(ctx);
              // थेट "All files access" permission page उघडतो (generic app settings नाही)
              await Permission.manageExternalStorage.request();
            },
            icon: const Icon(Icons.settings, size: 18),
            label: const Text('Settings उघडा', style: TextStyle(fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  void _loadLanguage() async {
    try {
      final s = await SettingsRepository().getSettings();
      if (mounted) setState(() { _currentLocale = Locale(s.language); });
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations(_currentLocale);
    return Localizations(
      locale: _currentLocale,
      delegates: const [
        AppLocalizationsDelegate(),
        DefaultMaterialLocalizations.delegate,
        DefaultWidgetsLocalizations.delegate,
      ],
      child: Scaffold(
        appBar: AppBar(
          title: const Text('ANURADHA MACHINERY STORES',
            style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white, fontSize: 16, letterSpacing: 0.5),
            maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center),
          backgroundColor: const Color(0xFFD32F2F),
          centerTitle: true,
          elevation: 4,
          toolbarHeight: 56,
        ),
        body: Column(
          children: [
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                padding: const EdgeInsets.all(16),
                crossAxisSpacing: 16,
                mainAxisSpacing: 16,
                children: [
                  MainDashboardCard(title: localizations.translate('new_invoice'), icon: Icons.add_shopping_cart, color: Colors.green,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InvoiceFormScreen())).then((_) => _loadLanguage())),
                  MainDashboardCard(title: localizations.translate('customers'), icon: Icons.people, color: Colors.blue,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CustomerListScreen())).then((_) => _loadLanguage())),
                  MainDashboardCard(title: localizations.translate('products'), icon: Icons.precision_manufacturing, color: Colors.orange,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ProductListScreen())).then((_) => _loadLanguage())),
                  MainDashboardCard(title: localizations.translate('invoice_history'), icon: Icons.history, color: Colors.purple,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const InvoiceHistoryScreen())).then((_) => _loadLanguage())),
                  MainDashboardCard(title: localizations.translate('settings'), icon: Icons.settings, color: Colors.blueGrey,
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen())).then((_) => _loadLanguage())),
                ],
              ),
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 16.0),
              child: Text('💗 THANOS 💖',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, color: Colors.grey, letterSpacing: 2)),
            ),
          ],
        ),
      ),
    );
  }
}
