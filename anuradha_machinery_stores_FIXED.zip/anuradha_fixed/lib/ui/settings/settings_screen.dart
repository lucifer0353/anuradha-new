import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:file_picker/file_picker.dart';
import '../widgets/phone_field_widget.dart';
import '../../data/models/country_code_model.dart';
import 'package:share_plus/share_plus.dart';
import '../../data/models/settings_model.dart';
import '../../data/repositories/settings_repository.dart';
import '../../data/database_helper.dart';
import '../../services/backup_service.dart';
import '../../services/save_path_service.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final _repo = SettingsRepository();
  final _formKey = GlobalKey<FormState>();

  final _addressCtrl = TextEditingController();
  final _dealerCtrl = TextEditingController();
  final _gstinCtrl = TextEditingController();
  final _mob1Ctrl = TextEditingController();
  final _mob2Ctrl = TextEditingController();
  String _mob1CountryCode = '+91';
  String _mob2CountryCode = '+91';
  final _email1Ctrl = TextEditingController();
  final _email2Ctrl = TextEditingController();
  final _owner1Ctrl = TextEditingController();
  final _desig1Ctrl = TextEditingController();
  final _bankCtrl = TextEditingController();
  final _accNameCtrl = TextEditingController();
  final _accNoCtrl = TextEditingController();
  final _ifscCtrl = TextEditingController();
  final _upiCtrl = TextEditingController();
  final _formatCtrl = TextEditingController();
  final _termsCtrl = TextEditingController();
  final _declarationCtrl = TextEditingController();
  final _jurisdictionCtrl = TextEditingController();
  String _selectedLanguage = 'en';

  String _logoPath = '';
  String _sigPath = '';
  String _qrPath = '';
  String _locationQrPath = '';

  // User-selected save paths
  String _pdfSavePath = '';
  String _backupSavePath = '';
  bool _enableRoundOff = false;

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _loadSettingsData();
    _loadSavePaths();
  }

  void _loadSavePaths() async {
    final pdfPath = await SavePathService.getSavePathDisplay();
    final backupPath = await SavePathService.getBackupPathDisplay();
    setState(() {
      _pdfSavePath = pdfPath.isNotEmpty ? pdfPath : 'Default (App Storage)';
      _backupSavePath = backupPath.isNotEmpty ? backupPath : 'Default (App Storage)';
    });
  }

  void _loadSettingsData() async {
    SettingsModel s = await _repo.getSettings();
    setState(() {
      _addressCtrl.text = s.address;
      _dealerCtrl.text = s.authorizedDealer;
      _gstinCtrl.text = s.gstin;
      // Parse saved mobile numbers — extract country code
      if (s.mobile1.startsWith('+')) {
        final parts = s.mobile1.split(' ');
        _mob1CountryCode = parts[0];
        _mob1Ctrl.text = parts.length >= 2 ? parts.sublist(1).join('') : '';
      } else {
        _mob1Ctrl.text = s.mobile1;
      }
      if (s.mobile2.startsWith('+')) {
        final parts = s.mobile2.split(' ');
        _mob2CountryCode = parts[0];
        _mob2Ctrl.text = parts.length >= 2 ? parts.sublist(1).join('') : '';
      } else {
        _mob2Ctrl.text = s.mobile2;
      }
      _email1Ctrl.text = s.email1;
      _email2Ctrl.text = s.email2;
      _owner1Ctrl.text = s.ownerName1;
      _desig1Ctrl.text = s.designation1;
      _bankCtrl.text = s.bankName;
      _accNameCtrl.text = s.accName;
      _accNoCtrl.text = s.accNumber;
      _ifscCtrl.text = s.ifscCode;
      _upiCtrl.text = s.upiId;
      _formatCtrl.text = s.invoiceFormat;
      _termsCtrl.text = s.terms;
      _declarationCtrl.text = s.declaration;
      _jurisdictionCtrl.text = s.jurisdiction;
      _selectedLanguage = s.language;
      _enableRoundOff = s.enableRoundOff;
      _logoPath = s.logoPath;
      _sigPath = s.sigPath1;
      _qrPath = s.qrPath;
      _locationQrPath = s.locationQrPath;
    });
  }

  Future<void> _pickImage(String type) async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      // Image ला external storage मध्ये copy करा — data clear झाली तरी safe राहते
      final savedPath = await _saveImagePermanently(image.path, type);
      setState(() {
        if (type == 'logo') _logoPath = savedPath;
        if (type == 'sig') _sigPath = savedPath;
        if (type == 'qr') _qrPath = savedPath;
        if (type == 'locationqr') _locationQrPath = savedPath;
      });
    }
  }

  // Image ला permanent external location मध्ये copy करणे
  Future<String> _saveImagePermanently(String sourcePath, String type) async {
    try {
      final source = File(sourcePath);
      final ext = sourcePath.split('.').last.toLowerCase();

      // App-specific external storage वापरणे — data clear झाली तरी हे delete होत नाही
      Directory? saveDir;
      try {
        final extDir = await getExternalStorageDirectory();
        if (extDir != null) {
          saveDir = Directory('\${extDir.path}/Anuradha_Images');
          if (!await saveDir.exists()) await saveDir.create(recursive: true);
        }
      } catch (_) {}

      saveDir ??= await getApplicationDocumentsDirectory();

      final destPath = '\${saveDir.path}/anuradha_\${type}_image.\$ext';
      await source.copy(destPath);
      return destPath;
    } catch (_) {
      // Copy fail झाली तरी original path वापरा
      return sourcePath;
    }
  }

  // PDF Save Folder निवडणे
  Future<void> _selectPdfSaveFolder() async {
    try {
      String? selectedDirectory = await FilePicker.platform.getDirectoryPath(
        dialogTitle: 'PDF Bills Save करण्यासाठी Folder निवडा',
      );
      if (selectedDirectory != null) {
        await SavePathService.setSavePath(selectedDirectory);
        setState(() { _pdfSavePath = selectedDirectory; });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('PDF Folder Set: $selectedDirectory'), backgroundColor: Colors.green),
          );
        }
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Folder निवडताना error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  // Backup Save Folder निवडणे
  Future<void> _selectBackupSaveFolder() async {
    try {
      String? selectedDirectory = await FilePicker.platform.getDirectoryPath(
        dialogTitle: 'Backup Save करण्यासाठी Folder निवडा',
      );
      if (selectedDirectory != null) {
        await SavePathService.setBackupPath(selectedDirectory);
        setState(() { _backupSavePath = selectedDirectory; });
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Backup Folder Set: $selectedDirectory'), backgroundColor: Colors.green),
          );
        }
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Folder निवडताना error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  // Backup बनवणे
  Future<void> _exportBackup() async {
    try {
      showDialog(context: context, barrierDismissible: false,
        builder: (_) => const Center(child: CircularProgressIndicator()));

      final backupPath = await BackupService.createLocalBackup();
      if (mounted) Navigator.pop(context);

      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Backup Successful ✅', style: TextStyle(color: Colors.green)),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Backup बनवला गेला!'),
                const SizedBox(height: 8),
                Text('📁 Path: $backupPath', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                const SizedBox(height: 8),
                const Text('हा backup app uninstall/data clear झाली तरी safe राहतो.', style: TextStyle(fontSize: 12, color: Colors.blue)),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
              TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  await Share.shareXFiles([XFile(backupPath)], text: 'Anuradha Machinery Stores - Database Backup');
                },
                child: const Text('Share Backup', style: TextStyle(color: Colors.green)),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        Navigator.pop(context);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Backup Failed: ${e.toString().replaceFirst('Exception: ', '')}'), backgroundColor: Colors.red),
        );
      }
    }
  }

  // Backup Restore करणे
  Future<void> _importBackup() async {
    try {
      // Backup files ची यादी दाखवा
      final backups = await BackupService.listLocalBackups();

      if (backups.isEmpty) {
        if (mounted) {
          showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: const Text('No Backup Found'),
              content: const Text('कोणताही backup file सापडला नाही.\n\nआधी "Export Backup" करा किंवा backup file phone वर असेल तर File Picker ने निवडा.'),
              actions: [
                TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
                TextButton(
                  onPressed: () async {
                    Navigator.pop(context);
                    await _pickAndRestoreBackup();
                  },
                  child: const Text('File निवडा', style: TextStyle(color: Colors.blue)),
                ),
              ],
            ),
          );
        }
        return;
      }

      // Backup list दाखवा
      if (mounted) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: const Text('Backup निवडा', style: TextStyle(fontWeight: FontWeight.bold)),
            content: SizedBox(
              width: double.maxFinite,
              child: ListView.builder(
                shrinkWrap: true,
                itemCount: backups.length,
                itemBuilder: (_, i) {
                  final file = backups[i];
                  final modified = file.statSync().modified;
                  final name = '${modified.day}/${modified.month}/${modified.year} ${modified.hour}:${modified.minute.toString().padLeft(2,'0')}';
                  return ListTile(
                    leading: const Icon(Icons.storage, color: Colors.blue),
                    title: Text(name),
                    subtitle: Text(file.path, style: const TextStyle(fontSize: 10)),
                    onTap: () async {
                      Navigator.pop(context);
                      await _doRestore(file.path);
                    },
                  );
                },
              ),
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
              TextButton(
                onPressed: () async {
                  Navigator.pop(context);
                  await _pickAndRestoreBackup();
                },
                child: const Text('वेगळी File निवडा'),
              ),
            ],
          ),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Restore Error: $e'), backgroundColor: Colors.red),
      );
    }
  }

  Future<void> _pickAndRestoreBackup() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.any,
      dialogTitle: 'Backup .db file निवडा',
    );
    if (result != null && result.files.single.path != null) {
      await _doRestore(result.files.single.path!);
    }
  }

  Future<void> _doRestore(String path) async {
    showDialog(context: context, barrierDismissible: false,
      builder: (_) => const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(color: Colors.white),
            SizedBox(height: 16),
            Material(color: Colors.transparent,
              child: Text('Restoring data...', style: TextStyle(color: Colors.white, fontSize: 16))),
          ],
        ),
      ));

    String? errorMessage;
    bool success = false;
    try {
      success = await BackupService.restoreLocalBackup(path);
    } catch (e) {
      success = false;
      errorMessage = e.toString().replaceFirst('Exception: ', '');
    }
    if (mounted) Navigator.pop(context);

    if (mounted) {
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => AlertDialog(
          title: Text(success ? 'Restore Successful 🎉' : 'Restore Failed ❌',
            style: TextStyle(color: success ? Colors.green : Colors.red)),
          content: Text(success
            ? 'सर्व data (customers, products, invoices, settings) restore झाला!\n\nOK दाबल्यावर app आपोआप restart होईल.'
            : (errorMessage ?? 'Restore होऊ शकला नाही. File valid आहे का ते check करा.')),
          actions: [
            TextButton(
              onPressed: () async {
                Navigator.pop(context);
                if (success) {
                  // App ला Dashboard पर्यंत पूर्ण pop करून fresh reload करणे
                  // यामुळे restored database fresh load होईल
                  Navigator.of(context).pushNamedAndRemoveUntil('/', (route) => false);
                } else {
                  Navigator.pop(context);
                }
              },
              child: Text(success ? 'OK - App Restart करा' : 'OK',
                style: TextStyle(color: success ? Colors.green : Colors.grey, fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Settings', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blueGrey,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [

            // ===== BACKUP & RESTORE =====
            _sectionHeader('📦 Data Safety - Backup & Restore'),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12)),
                    onPressed: _exportBackup,
                    icon: const Icon(Icons.backup),
                    label: const Text('Backup घ्या', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.blue, foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 12)),
                    onPressed: _importBackup,
                    icon: const Icon(Icons.restore),
                    label: const Text('Restore करा', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            // ===== SAVE PATH SELECTION =====
            _sectionHeader('📁 Files Save Location (Folder निवडा)'),

            // PDF Save Path
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(border: Border.all(color: Colors.grey[300]!), borderRadius: BorderRadius.circular(8)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('PDF Bills Save Folder', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(_pdfSavePath, style: const TextStyle(fontSize: 11, color: Colors.grey), maxLines: 2),
                  const SizedBox(height: 8),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.orange, foregroundColor: Colors.white),
                    onPressed: _selectPdfSaveFolder,
                    icon: const Icon(Icons.folder_open),
                    label: const Text('PDF Folder बदला'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),

            // Backup Save Path
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(border: Border.all(color: Colors.grey[300]!), borderRadius: BorderRadius.circular(8)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Backup Save Folder', style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(_backupSavePath, style: const TextStyle(fontSize: 11, color: Colors.grey), maxLines: 2),
                  const SizedBox(height: 8),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.purple, foregroundColor: Colors.white),
                    onPressed: _selectBackupSaveFolder,
                    icon: const Icon(Icons.folder_open),
                    label: const Text('Backup Folder बदला'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: Colors.blue[50], borderRadius: BorderRadius.circular(8)),
              child: const Row(
                children: [
                  Icon(Icons.info_outline, color: Colors.blue, size: 18),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Default: PDF → Downloads/Anuradha_Invoices\nBackup → Documents/Anuradha_Backups\nहे folders app uninstall झाली तरी delete होत नाहीत.',
                      style: TextStyle(fontSize: 11, color: Colors.blue),
                    ),
                  ),
                ],
              ),
            ),

            // ===== STORE SETTINGS =====
            _sectionHeader('🏪 Shop Settings'),
            DropdownButtonFormField<String>(
              value: _selectedLanguage,
              decoration: const InputDecoration(labelText: 'App Language', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'en', child: Text('English')),
                DropdownMenuItem(value: 'mr', child: Text('मराठी')),
              ],
              onChanged: (v) => setState(() { _selectedLanguage = v!; }),
            ),
            const SizedBox(height: 12),

            const SizedBox(height: 12),
            TextFormField(controller: _addressCtrl, decoration: const InputDecoration(labelText: 'Shop Address', border: OutlineInputBorder()), maxLines: 2),
            const SizedBox(height: 12),
            TextFormField(controller: _dealerCtrl, decoration: const InputDecoration(labelText: 'Authorized Dealer Text', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextFormField(controller: _gstinCtrl, decoration: const InputDecoration(labelText: 'GSTIN Number', border: OutlineInputBorder()), textCapitalization: TextCapitalization.characters),

            _sectionHeader('🖼️ Branding (Logo, Signature, QR Codes)'),
            _imageUploadTile(
              title: 'Shop Logo',
              subtitle: 'PDF वर डाव्या बाजूला दिसेल',
              path: _logoPath,
              onTap: () => _pickImage('logo'),
              onRemove: _logoPath.isNotEmpty ? () => setState(() { _logoPath = ''; }) : null,
            ),
            const SizedBox(height: 12),
            _imageUploadTile(
              title: 'Owner Signature',
              subtitle: 'PDF वर उजव्या खाली दिसेल',
              path: _sigPath,
              onTap: () => _pickImage('sig'),
              onRemove: _sigPath.isNotEmpty ? () => setState(() { _sigPath = ''; }) : null,
            ),
            const SizedBox(height: 12),
            _imageUploadTile(
              title: '💳 UPI QR Code',
              subtitle: 'PDF वर Bank details खाली दिसेल',
              path: _qrPath,
              onTap: () => _pickImage('qr'),
              onRemove: _qrPath.isNotEmpty ? () => setState(() { _qrPath = ''; }) : null,
            ),
            const SizedBox(height: 12),
            _imageUploadTile(
              title: '📍 Location QR Code',
              subtitle: 'PDF वर header मध्ये उजव्या बाजूला दिसेल — Customer scan करून shop location पाहू शकेल',
              path: _locationQrPath,
              onTap: () => _pickImage('locationqr'),
              onRemove: _locationQrPath.isNotEmpty ? () => setState(() { _locationQrPath = ''; }) : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _jurisdictionCtrl,
              decoration: const InputDecoration(
                labelText: 'Jurisdiction',
                border: OutlineInputBorder(),
                hintText: 'हा text Location QR च्या वर bold स्वरूपात print होईल',
              ),
            ),

            _sectionHeader('📞 Contact Information'),
            PhoneFieldWidget(
              controller: _mob1Ctrl,
              label: 'Mobile Number 1*',
              initialCountryCode: _mob1CountryCode,
              isRequired: true,
            ),
            const SizedBox(height: 12),
            PhoneFieldWidget(
              controller: _mob2Ctrl,
              label: 'Mobile Number 2 (Optional)',
              initialCountryCode: _mob2CountryCode,
              isRequired: false,
            ),
            const SizedBox(height: 12),
            TextFormField(controller: _email1Ctrl, decoration: const InputDecoration(labelText: 'Email Address', border: OutlineInputBorder())),

            _sectionHeader('👤 Owner Information'),
            TextFormField(controller: _owner1Ctrl, decoration: const InputDecoration(labelText: 'Owner / Signatory Name', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextFormField(controller: _desig1Ctrl, decoration: const InputDecoration(labelText: 'Designation (e.g. Proprietor)', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextFormField(controller: _formatCtrl, decoration: const InputDecoration(labelText: 'Invoice Number Format (e.g. AMS/2026/0001)', border: OutlineInputBorder())),


            _sectionHeader('🏦 Bank Details'),
            TextFormField(controller: _bankCtrl, decoration: const InputDecoration(labelText: 'Bank Name', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextFormField(controller: _accNameCtrl, decoration: const InputDecoration(labelText: 'Account Holder Name', border: OutlineInputBorder())),
            const SizedBox(height: 12),
            TextFormField(controller: _accNoCtrl, decoration: const InputDecoration(labelText: 'Account Number', border: OutlineInputBorder()), keyboardType: TextInputType.number),
            const SizedBox(height: 12),
            TextFormField(controller: _ifscCtrl, decoration: const InputDecoration(labelText: 'IFSC Code', border: OutlineInputBorder()), textCapitalization: TextCapitalization.characters),

            _sectionHeader('📋 Terms & Conditions'),
            TextFormField(controller: _termsCtrl, decoration: const InputDecoration(labelText: 'Invoice Terms & Conditions', border: OutlineInputBorder()), maxLines: 3),
            const SizedBox(height: 12),
            TextFormField(
              controller: _declarationCtrl,
              decoration: const InputDecoration(
                labelText: 'Declaration (Terms & Conditions खाली print होईल)',
                border: OutlineInputBorder(),
                hintText: 'e.g. Certified that the particulars given above are true and correct...',
              ),
              maxLines: 3,
            ),

            const SizedBox(height: 24),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueGrey,
                minimumSize: const Size.fromHeight(54),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () async {
                final s = SettingsModel(
                  id: 1, address: _addressCtrl.text.trim(), authorizedDealer: _dealerCtrl.text.trim(),
                  gstin: _gstinCtrl.text.trim().toUpperCase(), mobile1: _mob1Ctrl.text.trim(), mobile2: _mob2Ctrl.text.trim(),
                  email1: _email1Ctrl.text.trim(), email2: _email2Ctrl.text.trim(), logoPath: _logoPath,
                  ownerName1: _owner1Ctrl.text.trim(), designation1: _desig1Ctrl.text.trim(), sigPath1: _sigPath,
                  ownerName2: '', designation2: '', sigPath2: '', qrPath: _qrPath, locationQrPath: _locationQrPath,
                  bankName: _bankCtrl.text.trim(), accName: _accNameCtrl.text.trim(), accNumber: _accNoCtrl.text.trim(),
                  ifscCode: _ifscCtrl.text.trim().toUpperCase(), upiId: _upiCtrl.text.trim(),
                  invoiceFormat: _formatCtrl.text.trim(),
                  invoiceTitle: 'Tax Invoice', terms: _termsCtrl.text.trim(), declaration: _declarationCtrl.text.trim(), language: _selectedLanguage,
                  jurisdiction: _jurisdictionCtrl.text.trim(),
                );
                await _repo.updateSettings(s);
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('✅ Settings Saved!'), backgroundColor: Colors.green),
                );
              },
              child: const Text('Save Settings', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _sectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.blueGrey)),
          const Divider(thickness: 1),
        ],
      ),
    );
  }

  Widget _imageUploadTile({
    required String title,
    String subtitle = '',
    required String path,
    required VoidCallback onTap,
    VoidCallback? onRemove,
  }) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        border: Border.all(color: path.isNotEmpty ? Colors.green[300]! : Colors.grey[300]!),
        borderRadius: BorderRadius.circular(8),
        color: path.isNotEmpty ? Colors.green[50] : null,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                    if (subtitle.isNotEmpty)
                      Text(subtitle, style: const TextStyle(fontSize: 11, color: Colors.blueGrey)),
                    const SizedBox(height: 4),
                    Text(
                      path.isEmpty ? '📂 Upload केलेले नाही' : '✅ ${path.split('/').last}',
                      style: TextStyle(fontSize: 11, color: path.isEmpty ? Colors.grey : Colors.green[700]),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
              if (path.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(6),
                  child: Image.file(File(path), width: 52, height: 52, fit: BoxFit.cover),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueGrey,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                ),
                onPressed: onTap,
                icon: const Icon(Icons.upload, size: 16),
                label: Text(path.isEmpty ? 'Upload करा' : 'बदला'),
              ),
              if (onRemove != null) ...[
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.red,
                    side: const BorderSide(color: Colors.red),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  ),
                  onPressed: onRemove,
                  icon: const Icon(Icons.delete_outline, size: 16),
                  label: const Text('Remove'),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}
