class SettingsModel {
  final int id;
  final String address;
  final String authorizedDealer;
  final String gstin;
  final String mobile1;
  final String mobile2;
  final String email1;
  final String email2;
  final String logoPath;
  final String ownerName1;
  final String designation1;
  final String sigPath1;
  final String ownerName2;
  final String designation2;
  final String sigPath2;
  final String qrPath;
  final String locationQrPath;
  final String bankName;
  final String accName;
  final String accNumber;
  final String ifscCode;
  final String upiId;
  final String invoiceFormat;
  final String invoiceTitle; // e.g. "Tax Invoice", "Retail Invoice"
  final String terms;
  final String declaration;
  final String language;
  final bool enableRoundOff;
  final String jurisdiction; // Location QR च्या वर print होणारा custom bold text

  SettingsModel({
    required this.id,
    required this.address,
    required this.authorizedDealer,
    required this.gstin,
    required this.mobile1,
    required this.mobile2,
    required this.email1,
    required this.email2,
    required this.logoPath,
    required this.ownerName1,
    required this.designation1,
    required this.sigPath1,
    required this.ownerName2,
    required this.designation2,
    required this.sigPath2,
    required this.qrPath,
    required this.locationQrPath,
    required this.bankName,
    required this.accName,
    required this.accNumber,
    required this.ifscCode,
    required this.upiId,
    required this.invoiceFormat,
    this.invoiceTitle = 'Tax Invoice',
    required this.terms,
    this.declaration = '',
    required this.language,
    this.enableRoundOff = false,
    this.jurisdiction = '',
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'address': address,
    'authorizedDealer': authorizedDealer,
    'gstin': gstin,
    'mobile1': mobile1,
    'mobile2': mobile2,
    'email1': email1,
    'email2': email2,
    'logoPath': logoPath,
    'ownerName1': ownerName1,
    'designation1': designation1,
    'sigPath1': sigPath1,
    'ownerName2': ownerName2,
    'designation2': designation2,
    'sigPath2': sigPath2,
    'qrPath': qrPath,
    'locationQrPath': locationQrPath,
    'bankName': bankName,
    'accName': accName,
    'accNumber': accNumber,
    'ifscCode': ifscCode,
    'upiId': upiId,
    'invoiceFormat': invoiceFormat,
    'invoiceTitle': invoiceTitle,
    'terms': terms,
    'declaration': declaration,
    'language': language,
    'enableRoundOff': enableRoundOff ? 1 : 0,
    'jurisdiction': jurisdiction,
  };

  factory SettingsModel.fromMap(Map<String, dynamic> map) => SettingsModel(
    id: map['id'] ?? 1,
    address: map['address'] ?? '',
    authorizedDealer: map['authorizedDealer'] ?? '',
    gstin: map['gstin'] ?? '',
    mobile1: map['mobile1'] ?? '',
    mobile2: map['mobile2'] ?? '',
    email1: map['email1'] ?? '',
    email2: map['email2'] ?? '',
    logoPath: map['logoPath'] ?? '',
    ownerName1: map['ownerName1'] ?? '',
    designation1: map['designation1'] ?? '',
    sigPath1: map['sigPath1'] ?? '',
    ownerName2: map['ownerName2'] ?? '',
    designation2: map['designation2'] ?? '',
    sigPath2: map['sigPath2'] ?? '',
    qrPath: map['qrPath'] ?? '',
    locationQrPath: map['locationQrPath'] ?? '',
    bankName: map['bankName'] ?? '',
    accName: map['accName'] ?? '',
    accNumber: map['accNumber'] ?? '',
    ifscCode: map['ifscCode'] ?? '',
    upiId: map['upiId'] ?? '',
    invoiceFormat: map['invoiceFormat'] ?? 'INV-0001',
    invoiceTitle: map['invoiceTitle'] ?? 'Tax Invoice',
    terms: map['terms'] ?? '',
    declaration: map['declaration'] ?? '',
    language: map['language'] ?? 'en',
    enableRoundOff: (map['enableRoundOff'] as int? ?? 0) == 1,
    jurisdiction: map['jurisdiction'] ?? '',
  );
}
