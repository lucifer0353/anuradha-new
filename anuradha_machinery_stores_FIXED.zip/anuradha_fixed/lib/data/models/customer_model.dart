class CustomerModel {
  final int? id;
  final String name;
  final String mobile;
  final String gatNumber;
  final String area;
  final String areaUnit;      // Acre, Hectare, etc.
  final String crop;
  final String remarks;
  final String address;       // Free text address
  final String state;         // State name
  final String district;      // District (user types)
  final String subDistrict;   // Sub-district/Taluka (user types)
  final String stateCode;     // e.g. MH (user types)
  final String gstin;

  CustomerModel({
    this.id,
    required this.name,
    required this.mobile,
    required this.gatNumber,
    required this.area,
    this.areaUnit = 'Acre (एकर)',
    required this.crop,
    required this.remarks,
    required this.address,
    this.state = '',
    this.district = '',
    this.subDistrict = '',
    this.stateCode = '',
    required this.gstin,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'mobile': mobile,
    'gatNumber': gatNumber,
    'area': area,
    'areaUnit': areaUnit,
    'crop': crop,
    'remarks': remarks,
    'address': address,
    'state': state,
    'district': district,
    'subDistrict': subDistrict,
    'stateCode': stateCode,
    'gstin': gstin,
  };

  factory CustomerModel.fromMap(Map<String, dynamic> map) => CustomerModel(
    id: map['id'],
    name: map['name'] ?? '',
    mobile: map['mobile'] ?? '',
    gatNumber: map['gatNumber'] ?? '',
    area: map['area'] ?? '',
    areaUnit: map['areaUnit'] ?? 'Acre (एकर)',
    crop: map['crop'] ?? '',
    remarks: map['remarks'] ?? '',
    address: map['address'] ?? '',
    state: map['state'] ?? '',
    district: map['district'] ?? '',
    subDistrict: map['subDistrict'] ?? '',
    stateCode: map['stateCode'] ?? '',
    gstin: map['gstin'] ?? '',
  );
}
