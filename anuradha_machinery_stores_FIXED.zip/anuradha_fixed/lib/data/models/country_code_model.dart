class CountryCode {
  final String name;
  final String code;    // +91
  final String flag;    // 🇮🇳
  final int digits;     // 10

  const CountryCode({
    required this.name,
    required this.code,
    required this.flag,
    required this.digits,
  });

  String get display => '$flag $code';
}

// Most common countries — India default
const List<CountryCode> kCountryCodes = [
  CountryCode(name: 'India', code: '+91', flag: '🇮🇳', digits: 10),
  CountryCode(name: 'USA', code: '+1', flag: '🇺🇸', digits: 10),
  CountryCode(name: 'UK', code: '+44', flag: '🇬🇧', digits: 10),
  CountryCode(name: 'UAE', code: '+971', flag: '🇦🇪', digits: 9),
  CountryCode(name: 'Saudi Arabia', code: '+966', flag: '🇸🇦', digits: 9),
  CountryCode(name: 'Australia', code: '+61', flag: '🇦🇺', digits: 9),
  CountryCode(name: 'Canada', code: '+1', flag: '🇨🇦', digits: 10),
  CountryCode(name: 'Germany', code: '+49', flag: '🇩🇪', digits: 11),
  CountryCode(name: 'France', code: '+33', flag: '🇫🇷', digits: 9),
  CountryCode(name: 'Singapore', code: '+65', flag: '🇸🇬', digits: 8),
  CountryCode(name: 'Nepal', code: '+977', flag: '🇳🇵', digits: 10),
  CountryCode(name: 'Bangladesh', code: '+880', flag: '🇧🇩', digits: 10),
  CountryCode(name: 'Pakistan', code: '+92', flag: '🇵🇰', digits: 10),
  CountryCode(name: 'Sri Lanka', code: '+94', flag: '🇱🇰', digits: 9),
  CountryCode(name: 'South Africa', code: '+27', flag: '🇿🇦', digits: 9),
  CountryCode(name: 'Nigeria', code: '+234', flag: '🇳🇬', digits: 10),
  CountryCode(name: 'Kenya', code: '+254', flag: '🇰🇪', digits: 9),
  CountryCode(name: 'Malaysia', code: '+60', flag: '🇲🇾', digits: 10),
  CountryCode(name: 'Indonesia', code: '+62', flag: '🇮🇩', digits: 10),
  CountryCode(name: 'Japan', code: '+81', flag: '🇯🇵', digits: 10),
  CountryCode(name: 'China', code: '+86', flag: '🇨🇳', digits: 11),
];
