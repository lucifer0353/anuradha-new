class InvoiceModel {
  int? id;
  String invoiceNumber;
  String date;
  String time;
  int customerId;
  String customerName;
  String customerMobile;
  String customerGstin;
  String customerGat;
  String customerArea;
  String customerCrop;
  String customerRemarks;
  String customerAddress;
  String customerState;
  String customerDistrict;
  String customerSubDistrict;
  String customerStateCode;
  String customerAreaUnit;
  double productTotal;      // Sum of all items before bill discount
  double billDiscount;      // Overall bill discount amount
  double billDiscountPct;   // Overall bill discount percentage
  double taxableAmount;     // After bill discount
  double cgst;
  double sgst;
  double igst;
  double totalGst;
  double grandTotal;        // Before round off
  double roundOff;          // +/- round off value
  double finalAmount;       // Grand Total + Round Off
  String amountInWords;
  String paymentStatus;
  List<InvoiceItemModel> items;

  InvoiceModel({
    this.id,
    required this.invoiceNumber,
    required this.date,
    required this.time,
    required this.customerId,
    required this.customerName,
    required this.customerMobile,
    this.customerGstin = '',
    this.customerGat = '',
    this.customerArea = '',
    this.customerCrop = '',
    this.customerRemarks = '',
    this.customerAddress = '',
    this.customerState = '',
    this.customerDistrict = '',
    this.customerSubDistrict = '',
    this.customerStateCode = '',
    this.customerAreaUnit = '',
    this.productTotal = 0.0,
    this.billDiscount = 0.0,
    this.billDiscountPct = 0.0,
    required this.taxableAmount,
    required this.cgst,
    required this.sgst,
    this.igst = 0.0,
    required this.totalGst,
    required this.grandTotal,
    this.roundOff = 0.0,
    double? finalAmount,
    required this.amountInWords,
    required this.paymentStatus,
    required this.items,
  }) : finalAmount = finalAmount ?? grandTotal;

  Map<String, dynamic> toMap() => {
    'id': id,
    'invoiceNumber': invoiceNumber,
    'date': date,
    'time': time,
    'customerId': customerId,
    'customerName': customerName,
    'customerMobile': customerMobile,
    'customerGstin': customerGstin,
    'customerGat': customerGat,
    'customerArea': customerArea,
    'customerCrop': customerCrop,
    'customerRemarks': customerRemarks,
    'customerAddress': customerAddress,
    'customerState': customerState,
    'customerDistrict': customerDistrict,
    'customerSubDistrict': customerSubDistrict,
    'customerStateCode': customerStateCode,
    'customerAreaUnit': customerAreaUnit,
    'productTotal': productTotal,
    'billDiscount': billDiscount,
    'billDiscountPct': billDiscountPct,
    'taxableAmount': taxableAmount,
    'cgst': cgst,
    'sgst': sgst,
    'igst': igst,
    'totalGst': totalGst,
    'grandTotal': grandTotal,
    'roundOff': roundOff,
    'finalAmount': finalAmount,
    'amountInWords': amountInWords,
    'paymentStatus': paymentStatus,
  };

  factory InvoiceModel.fromMap(Map<String, dynamic> map, List<InvoiceItemModel> itemsList) => InvoiceModel(
    id: map['id'],
    invoiceNumber: map['invoiceNumber'] ?? '',
    date: map['date'] ?? '',
    time: map['time'] ?? '',
    customerId: map['customerId'] ?? 0,
    customerName: map['customerName'] ?? '',
    customerMobile: map['customerMobile'] ?? '',
    customerGstin: map['customerGstin'] ?? '',
    customerGat: map['customerGat'] ?? '',
    customerArea: map['customerArea'] ?? '',
    customerCrop: map['customerCrop'] ?? '',
    customerRemarks: map['customerRemarks'] ?? '',
    customerAddress: map['customerAddress'] ?? '',
    customerState: map['customerState'] ?? '',
    customerDistrict: map['customerDistrict'] ?? '',
    customerSubDistrict: map['customerSubDistrict'] ?? '',
    customerStateCode: map['customerStateCode'] ?? '',
    customerAreaUnit: map['customerAreaUnit'] ?? '',
    productTotal: (map['productTotal'] as num?)?.toDouble() ?? 0.0,
    billDiscount: (map['billDiscount'] as num?)?.toDouble() ?? 0.0,
    billDiscountPct: (map['billDiscountPct'] as num?)?.toDouble() ?? 0.0,
    taxableAmount: (map['taxableAmount'] as num?)?.toDouble() ?? 0.0,
    cgst: (map['cgst'] as num?)?.toDouble() ?? 0.0,
    sgst: (map['sgst'] as num?)?.toDouble() ?? 0.0,
    igst: (map['igst'] as num?)?.toDouble() ?? 0.0,
    totalGst: (map['totalGst'] as num?)?.toDouble() ?? 0.0,
    grandTotal: (map['grandTotal'] as num?)?.toDouble() ?? 0.0,
    roundOff: (map['roundOff'] as num?)?.toDouble() ?? 0.0,
    finalAmount: (map['finalAmount'] as num?)?.toDouble(),
    amountInWords: map['amountInWords'] ?? '',
    paymentStatus: map['paymentStatus'] ?? 'Paid',
    items: itemsList,
  );
}

class InvoiceItemModel {
  int? id;
  String? invoiceNumber;
  String productName;
  String hsnCode;
  String cmlNumber;
  String batchNumber;
  double quantity;
  String unit;
  double companyRate;
  double saleRate;
  double discountPct;    // Item level discount %
  double discountAmt;    // Item level discount fixed ₹
  double discountedRate; // Rate after discount
  double gstPercentage;
  double amount;         // Final amount after discount + GST

  InvoiceItemModel({
    this.id,
    this.invoiceNumber,
    required this.productName,
    this.hsnCode = '',
    this.cmlNumber = '',
    this.batchNumber = '',
    required this.quantity,
    this.unit = 'Piece',
    this.companyRate = 0.0,
    required this.saleRate,
    this.discountPct = 0.0,
    this.discountAmt = 0.0,
    double? discountedRate,
    required this.gstPercentage,
    required this.amount,
  }) : discountedRate = discountedRate ?? saleRate;
}
