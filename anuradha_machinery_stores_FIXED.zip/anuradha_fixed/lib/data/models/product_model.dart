class ProductModel {
  final int? id;
  final String name;
  final String hsnCode;
  final String cmlNumber;
  final String batchNumber;
  final double companyRate;
  final double saleRate;
  final double gstPercentage;
  final String unitType;

  ProductModel({
    this.id,
    required this.name,
    required this.hsnCode,
    required this.cmlNumber,
    required this.batchNumber,
    required this.companyRate,
    required this.saleRate,
    required this.gstPercentage,
    required this.unitType,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'name': name,
    'hsnCode': hsnCode,
    'cmlNumber': cmlNumber,
    'batchNumber': batchNumber,
    'companyRate': companyRate,
    'saleRate': saleRate,
    'gstPercentage': gstPercentage,
    'unitType': unitType,
  };

  factory ProductModel.fromMap(Map<String, dynamic> map) => ProductModel(
    id: map['id'],
    name: map['name'] ?? '',
    hsnCode: map['hsnCode'] ?? '',
    cmlNumber: map['cmlNumber'] ?? '',
    batchNumber: map['batchNumber'] ?? '',
    companyRate: (map['companyRate'] as num?)?.toDouble() ?? 0.0,
    saleRate: (map['saleRate'] as num?)?.toDouble() ?? 0.0,
    gstPercentage: (map['gstPercentage'] as num?)?.toDouble() ?? 0.0,
    unitType: map['unitType'] ?? 'Piece',
  );
}
