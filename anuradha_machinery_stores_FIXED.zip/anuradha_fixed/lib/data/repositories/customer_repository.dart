import 'package:sqflite/sqflite.dart';
import '../database_helper.dart';
import '../models/customer_model.dart';

class CustomerRepository {
  final _dbHelper = DatabaseHelper.instance;

  // 🛠️ नवीन ग्राहक जोडणे (मेथडचे नाव अपडेट केले)
  Future<int> insertCustomer(CustomerModel customer) async {
    final db = await _dbHelper.database;
    return await db.insert('customers', customer.toMap());
  }

  // नाव किंवा मोबाईल नंबर वरून शोधणे
  Future<List<CustomerModel>> searchCustomers(String query) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'customers',
      where: 'name LIKE ? OR mobile LIKE ? OR area LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%'],
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => CustomerModel.fromMap(maps[i]));
  }

  // 🛠️ ग्राहक प्रोफाइल अपडेट करणे (मेथडचे नाव अपडेट केले)
  Future<int> updateCustomer(CustomerModel customer) async {
    final db = await _dbHelper.database;
    return await db.update(
      'customers',
      customer.toMap(),
      where: 'id = ?',
      whereArgs: [customer.id],
    );
  }

  // ग्राहक डिलीट करणे
  Future<int> deleteCustomer(int id) async {
    final db = await _dbHelper.database;
    return await db.delete(
      'customers',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
