import 'package:sqflite/sqflite.dart';
import '../database_helper.dart';
import '../models/product_model.dart';

class ProductRepository {
  final _dbHelper = DatabaseHelper.instance;

  // नवीन उत्पादन डेटाबेसमध्ये साठवणे
  Future<int> insert(ProductModel product) async {
    final db = await _dbHelper.database;
    return await db.insert('products', product.toMap());
  }

  // सर्व उत्पादनांची यादी मिळवणे (ही नवीन मेथड आपण जोडली आहे 🛠️)
  Future<List<ProductModel>> getAllProducts() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query('products', orderBy: 'name ASC');
    return List.generate(maps.length, (i) => ProductModel.fromMap(maps[i]));
  }

  // नाव किंवा HSN कोडनुसार उत्पादन शोधणे
  Future<List<ProductModel>> searchProducts(String query) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'products',
      where: 'name LIKE ? OR hsnCode LIKE ?',
      whereArgs: ['%$query%', '%$query%'],
      orderBy: 'name ASC',
    );
    return List.generate(maps.length, (i) => ProductModel.fromMap(maps[i]));
  }

  // उत्पादनाची माहिती अपडेट करणे
  Future<int> update(ProductModel product) async {
    final db = await _dbHelper.database;
    return await db.update(
      'products',
      product.toMap(),
      where: 'id = ?',
      whereArgs: [product.id],
    );
  }

  // उत्पादन डेटाबेसमधून डिलीट करणे
  Future<int> delete(int id) async {
    final db = await _dbHelper.database;
    return await db.delete(
      'products',
      where: 'id = ?',
      whereArgs: [id],
    );
  }
}
