import 'package:sqflite/sqflite.dart';
import '../database_helper.dart';
import '../models/invoice_model.dart';

class InvoiceRepository {
  final _dbHelper = DatabaseHelper.instance;

  Future<void> createInvoice(InvoiceModel invoice) async {
    final db = await _dbHelper.database;
    await db.transaction((txn) async {
      await txn.insert('invoices', {
        'invoiceNumber': invoice.invoiceNumber,
        'date': invoice.date,
        'time': invoice.time,
        'customerId': invoice.customerId,
        'customerName': invoice.customerName,
        'customerMobile': invoice.customerMobile,
        'customerGstin': invoice.customerGstin,
        'customerGat': invoice.customerGat,
        'customerArea': invoice.customerArea,
        'customerCrop': invoice.customerCrop,
        'customerRemarks': invoice.customerRemarks,
        'customerAddress': invoice.customerAddress,
        'customerState': invoice.customerState,
        'customerDistrict': invoice.customerDistrict,
        'customerSubDistrict': invoice.customerSubDistrict,
        'customerStateCode': invoice.customerStateCode,
        'customerAreaUnit': invoice.customerAreaUnit,
        'productTotal': invoice.productTotal,
        'billDiscount': invoice.billDiscount,
        'billDiscountPct': invoice.billDiscountPct,
        'taxableAmount': invoice.taxableAmount,
        'cgst': invoice.cgst,
        'sgst': invoice.sgst,
        'igst': invoice.igst,
        'totalGst': invoice.totalGst,
        'grandTotal': invoice.grandTotal,
        'roundOff': invoice.roundOff,
        'finalAmount': invoice.finalAmount,
        'amountInWords': invoice.amountInWords,
        'paymentStatus': invoice.paymentStatus,
      });

      for (var item in invoice.items) {
        await txn.insert('invoice_items', {
          'invoiceNumber': invoice.invoiceNumber,
          'productName': item.productName,
          'hsnCode': item.hsnCode,
          'cmlNumber': item.cmlNumber,
          'batchNumber': item.batchNumber,
          'quantity': item.quantity,
          'unit': item.unit,
          'companyRate': item.companyRate,
          'saleRate': item.saleRate,
          'discountPct': item.discountPct,
          'discountAmt': item.discountAmt,
          'discountedRate': item.discountedRate,
          'gstPercentage': item.gstPercentage,
          'amount': item.amount,
        });
      }
    });
  }

  Future<List<InvoiceModel>> getInvoiceHistory() async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query('invoices', orderBy: 'id DESC');

    List<InvoiceModel> invoices = [];
    for (var map in maps) {
      final List<Map<String, dynamic>> itemMaps = await db.query(
        'invoice_items',
        where: 'invoiceNumber = ?',
        whereArgs: [map['invoiceNumber']],
      );

      List<InvoiceItemModel> items = itemMaps.map((i) => InvoiceItemModel(
        productName: i['productName'] ?? '',
        hsnCode: i['hsnCode'] ?? '',
        cmlNumber: i['cmlNumber'] ?? '',
        batchNumber: i['batchNumber'] ?? '',
        quantity: (i['quantity'] as num?)?.toDouble() ?? 0.0,
        unit: i['unit'] ?? 'Piece',
        companyRate: (i['companyRate'] as num?)?.toDouble() ?? 0.0,
        saleRate: (i['saleRate'] as num?)?.toDouble() ?? 0.0,
        discountPct: (i['discountPct'] as num?)?.toDouble() ?? 0.0,
        discountAmt: (i['discountAmt'] as num?)?.toDouble() ?? 0.0,
        discountedRate: (i['discountedRate'] as num?)?.toDouble() ?? 0.0,
        gstPercentage: (i['gstPercentage'] as num?)?.toDouble() ?? 0.0,
        amount: (i['amount'] as num?)?.toDouble() ?? 0.0,
      )).toList();

      invoices.add(InvoiceModel.fromMap(map, items));
    }
    return invoices;
  }

  Future<void> deleteInvoice(int id) async {
    final db = await _dbHelper.database;
    final List<Map<String, dynamic>> maps = await db.query('invoices', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) {
      String invNum = maps.first['invoiceNumber'];
      await db.delete('invoice_items', where: 'invoiceNumber = ?', whereArgs: [invNum]);
      await db.delete('invoices', where: 'id = ?', whereArgs: [id]);
    }
  }
}
