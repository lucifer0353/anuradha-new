import 'package:sqflite/sqflite.dart';
import '../database_helper.dart';
import '../models/settings_model.dart';

class SettingsRepository {
  final _dbHelper = DatabaseHelper.instance;

  // सेटिंग्ज मिळवणे (नेहमी ID = 1 असलेली रो वापरली जाईल)
  Future<SettingsModel> getSettings() async {
    final db = await _dbHelper.database;
    final res = await db.query('settings', where: 'id = 1');
    if (res.isNotEmpty) {
      return SettingsModel.fromMap(res.first);
    }
    // बॅकअप म्हणून जर रो नसेल तर नवीन तयार करणे
    SettingsModel defaultSettings = SettingsModel(
      id: 1, address: '', authorizedDealer: '', gstin: '', mobile1: '', mobile2: '',
      email1: '', email2: '', logoPath: '', ownerName1: '', designation1: '', sigPath1: '',
      ownerName2: '', designation2: '', sigPath2: '', qrPath: '', locationQrPath: '', bankName: '', accName: '',
      accNumber: '', ifscCode: '', upiId: '', invoiceFormat: 'AMS/2026/0001', invoiceTitle: 'Tax Invoice', terms: '', declaration: '', language: 'en', enableRoundOff: false,
    );
    await db.insert('settings', defaultSettings.toMap());
    return defaultSettings;
  }

  // सेटिंग्ज अपडेट करणे
  Future<int> updateSettings(SettingsModel settings) async {
    final db = await _dbHelper.database;
    return await db.update(
      'settings', 
      settings.toMap(), 
      where: 'id = 1',
    );
  }
}
