import 'dart:io';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class DatabaseHelper {
  static const _databaseName = "AnuradhaStores.db";
  static const _databaseVersion = 7; // Version 7 — jurisdiction (Location QR वरचा text) added

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<String> getDatabasePath() async {
    final documentsDirectory = await getApplicationDocumentsDirectory();
    return join(documentsDirectory.path, _databaseName);
  }

  _initDatabase() async {
    String path = await getDatabasePath();
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> closeDatabase() async {
    try {
      if (_database != null && _database!.isOpen) {
        await _database!.close();
      }
    } catch (_) {}
    _database = null;
  }

  Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 7) {
      try { await db.execute("ALTER TABLE settings ADD COLUMN jurisdiction TEXT DEFAULT ''"); } catch (_) {}
    }
    if (oldVersion < 2) {
      try { await db.execute("ALTER TABLE settings ADD COLUMN locationQrPath TEXT DEFAULT ''"); } catch (_) {}
    }
    if (oldVersion < 6) {
      try { await db.execute("ALTER TABLE settings ADD COLUMN declaration TEXT DEFAULT ''"); } catch (_) {}
    }
    if (oldVersion < 5) {
      try { await db.execute("ALTER TABLE customers ADD COLUMN areaUnit TEXT DEFAULT 'Acre (एकर)'"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN customerState TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN customerDistrict TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN customerSubDistrict TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN customerStateCode TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN customerAreaUnit TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE customers ADD COLUMN state TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE customers ADD COLUMN district TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE customers ADD COLUMN subDistrict TEXT DEFAULT ''"); } catch (_) {}
      try { await db.execute("ALTER TABLE customers ADD COLUMN stateCode TEXT DEFAULT ''"); } catch (_) {}
    }
    if (oldVersion < 4) {
      try { await db.execute("ALTER TABLE settings ADD COLUMN invoiceTitle TEXT DEFAULT 'Tax Invoice'"); } catch (_) {}
    }
    if (oldVersion < 3) {
      // Invoice new fields
      try { await db.execute("ALTER TABLE invoices ADD COLUMN productTotal REAL DEFAULT 0"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN billDiscount REAL DEFAULT 0"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN billDiscountPct REAL DEFAULT 0"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN roundOff REAL DEFAULT 0"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoices ADD COLUMN finalAmount REAL DEFAULT 0"); } catch (_) {}
      // Invoice items new fields
      try { await db.execute("ALTER TABLE invoice_items ADD COLUMN discountPct REAL DEFAULT 0"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoice_items ADD COLUMN discountAmt REAL DEFAULT 0"); } catch (_) {}
      try { await db.execute("ALTER TABLE invoice_items ADD COLUMN discountedRate REAL DEFAULT 0"); } catch (_) {}
      // Settings new fields
      try { await db.execute("ALTER TABLE settings ADD COLUMN enableRoundOff INTEGER DEFAULT 0"); } catch (_) {}
      // Draft table
      try {
        await db.execute('''
          CREATE TABLE IF NOT EXISTS invoice_draft (
            id INTEGER PRIMARY KEY,
            draftData TEXT NOT NULL,
            updatedAt TEXT NOT NULL
          )
        ''');
      } catch (_) {}
    }
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        hsnCode TEXT,
        cmlNumber TEXT,
        batchNumber TEXT,
        companyRate REAL,
        saleRate REAL,
        gstPercentage REAL,
        unitType TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE customers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        mobile TEXT NOT NULL,
        address TEXT,
        state TEXT,
        district TEXT,
        subDistrict TEXT,
        stateCode TEXT,
        gatNumber TEXT,
        area TEXT,
        areaUnit TEXT,
        crop TEXT,
        gstin TEXT,
        remarks TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE invoices (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoiceNumber TEXT NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        customerId INTEGER NOT NULL,
        customerName TEXT NOT NULL,
        customerMobile TEXT NOT NULL,
        customerGstin TEXT,
        customerGat TEXT,
        customerArea TEXT,
        customerCrop TEXT,
        customerRemarks TEXT,
        customerAddress TEXT,
        customerState TEXT,
        customerDistrict TEXT,
        customerSubDistrict TEXT,
        customerStateCode TEXT,
        customerAreaUnit TEXT,
        productTotal REAL,
        billDiscount REAL,
        billDiscountPct REAL,
        taxableAmount REAL,
        cgst REAL,
        sgst REAL,
        igst REAL,
        totalGst REAL,
        grandTotal REAL,
        roundOff REAL,
        finalAmount REAL,
        amountInWords TEXT,
        paymentStatus TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE invoice_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        invoiceNumber TEXT NOT NULL,
        productName TEXT NOT NULL,
        hsnCode TEXT,
        cmlNumber TEXT,
        batchNumber TEXT,
        quantity REAL,
        unit TEXT,
        companyRate REAL,
        saleRate REAL,
        discountPct REAL DEFAULT 0,
        discountAmt REAL DEFAULT 0,
        discountedRate REAL DEFAULT 0,
        gstPercentage REAL,
        amount REAL
      )
    ''');

    await db.execute('''
      CREATE TABLE settings (
        id INTEGER PRIMARY KEY,
        address TEXT, authorizedDealer TEXT, gstin TEXT,
        mobile1 TEXT, mobile2 TEXT, email1 TEXT, email2 TEXT,
        logoPath TEXT, ownerName1 TEXT, designation1 TEXT, sigPath1 TEXT,
        ownerName2 TEXT, designation2 TEXT, sigPath2 TEXT, qrPath TEXT, locationQrPath TEXT,
        bankName TEXT, accName TEXT, accNumber TEXT, ifscCode TEXT, upiId TEXT,
        invoiceFormat TEXT, invoiceTitle TEXT, terms TEXT, declaration TEXT, language TEXT,
        enableRoundOff INTEGER DEFAULT 0, jurisdiction TEXT DEFAULT ''
      )
    ''');

    // Draft table — auto save draft साठी
    await db.execute('''
      CREATE TABLE invoice_draft (
        id INTEGER PRIMARY KEY,
        draftData TEXT NOT NULL,
        updatedAt TEXT NOT NULL
      )
    ''');

    await db.insert('settings', {
      'id': 1, 'address': '', 'authorizedDealer': '', 'gstin': '',
      'mobile1': '', 'mobile2': '', 'email1': '', 'email2': '',
      'logoPath': '', 'ownerName1': '', 'designation1': '', 'sigPath1': '',
      'ownerName2': '', 'designation2': '', 'sigPath2': '', 'qrPath': '', 'locationQrPath': '',
      'bankName': '', 'accName': '', 'accNumber': '', 'ifscCode': '', 'upiId': '',
      'invoiceFormat': 'AMS/2026/0001', 'invoiceTitle': 'Tax Invoice', 'terms': '1. Goods once sold will not be taken back.', 'declaration': '',
      'language': 'en', 'enableRoundOff': 0, 'jurisdiction': ''
    });
  }
}
