import 'package:flutter/material.dart';
import 'ui/dashboard/dashboard_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AnuradhaMachineryStoresApp());
}

class AnuradhaMachineryStoresApp extends StatelessWidget {
  const AnuradhaMachineryStoresApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Anuradha Machinery Stores',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        primaryColor: const Color(0xFFD32F2F),
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFD32F2F)),
      ),
      // Named routes — restore नंतर app fresh restart साठी
      initialRoute: '/',
      routes: {
        '/': (context) => const DashboardScreen(),
      },
    );
  }
}
