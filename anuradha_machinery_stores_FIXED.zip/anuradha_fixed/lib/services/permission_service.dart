import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';

// Permission status file — external storage मध्ये ठेवतो
// data clear झाली तरी हे राहतं, uninstall झाली तर जातं
// त्यामुळे: install → permission मागतो, data clear → permission मागत नाही (already given)
// uninstall + reinstall → permission मागतो
class PermissionService {
  static const String _fileName = 'anuradha_permissions.txt';
  static const String _key = 'all_files_granted';

  static Future<File?> _getFile() async {
    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir != null) return File(join(extDir.path, _fileName));
    } catch (_) {}
    try {
      final appDir = await getApplicationDocumentsDirectory();
      return File(join(appDir.path, _fileName));
    } catch (_) {}
    return null;
  }

  // Permission granted म्हणून mark करणे
  static Future<void> markPermissionGranted() async {
    try {
      final file = await _getFile();
      await file?.writeAsString('$_key=true', flush: true);
    } catch (_) {}
  }

  // Permission आधी granted झाली आहे का check करणे
  static Future<bool> isPermissionAlreadyGranted() async {
    try {
      final file = await _getFile();
      if (file == null || !await file.exists()) return false;
      final content = await file.readAsString();
      return content.contains('$_key=true');
    } catch (_) {
      return false;
    }
  }

  // Permission reset करणे (uninstall नंतर automatically reset होतो)
  static Future<void> resetPermission() async {
    try {
      final file = await _getFile();
      if (await file?.exists() == true) await file!.delete();
    } catch (_) {}
  }
}
