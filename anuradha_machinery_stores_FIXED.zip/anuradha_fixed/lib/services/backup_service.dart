import 'dart:io';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sqflite/sqflite.dart';
import '../data/database_helper.dart';
import 'save_path_service.dart';

class BackupService {
  static const String _dbName = 'AnuradhaStores.db';

  static Future<int> _getAndroidSdk() async {
    try {
      final result = await Process.run('getprop', ['ro.build.version.sdk']);
      return int.tryParse(result.stdout.toString().trim()) ?? 21;
    } catch (_) { return 21; }
  }

  // Permission check + request
  static Future<bool> requestPermissions() async {
    final sdk = await _getAndroidSdk();
    if (sdk >= 30) {
      final status = await Permission.manageExternalStorage.status;
      if (!status.isGranted) {
        final result = await Permission.manageExternalStorage.request();
        return result.isGranted;
      }
      return true;
    } else if (sdk >= 23) {
      final status = await Permission.storage.status;
      if (!status.isGranted) {
        final result = await Permission.storage.request();
        return result.isGranted;
      }
      return true;
    }
    return true;
  }

  static Future<Directory> _getBackupDirectory() async {
    // User ने निवडलेला path
    final userPath = await SavePathService.getBackupPath();
    if (userPath != null && userPath.isNotEmpty) {
      try {
        final userDir = Directory(userPath);
        if (!await userDir.exists()) await userDir.create(recursive: true);
        final testFile = File('${userDir.path}/.test');
        await testFile.writeAsString('test');
        await testFile.delete();
        return userDir;
      } catch (_) {}
    }

    // Default: app-specific external (permission नसली तरी चालते)
    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir != null) {
        final backupDir = Directory('${extDir.path}/Anuradha_Backups');
        if (!await backupDir.exists()) await backupDir.create(recursive: true);
        return backupDir;
      }
    } catch (_) {}

    // Fallback: internal
    final appDoc = await getApplicationDocumentsDirectory();
    final fallback = Directory('${appDoc.path}/Anuradha_Backups');
    if (!await fallback.exists()) await fallback.create(recursive: true);
    return fallback;
  }

  static Future<String> _getDbPath() async {
    final docsDir = await getApplicationDocumentsDirectory();
    return join(docsDir.path, _dbName);
  }

  // Logo/Signature/QR images जिथे permanent save होतात, तीच जागा वापरणे
  // (settings_screen.dart मधल्या _saveImagePermanently शी सुसंगत)
  static Future<Directory> _getImagesDirectory() async {
    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir != null) {
        final dir = Directory('${extDir.path}/Anuradha_Images');
        if (!await dir.exists()) await dir.create(recursive: true);
        return dir;
      }
    } catch (_) {}
    final appDoc = await getApplicationDocumentsDirectory();
    final dir = Directory('${appDoc.path}/Anuradha_Images');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  // Settings चा कुठला column, backup मधलं कुठलं नाव, आणि restore केल्यावर file चं नाव काय असावं
  static const Map<String, Map<String, String>> _imageFieldMap = {
    'logoPath':       {'key': 'logo',       'fileBase': 'anuradha_logo_image'},
    'sigPath1':       {'key': 'sig1',       'fileBase': 'anuradha_sig_image'},
    'sigPath2':       {'key': 'sig2',       'fileBase': 'anuradha_sig2_image'},
    'qrPath':         {'key': 'qr',         'fileBase': 'anuradha_qr_image'},
    'locationQrPath': {'key': 'locationqr', 'fileBase': 'anuradha_locationqr_image'},
  };

  // Backup बनवणे — database + shop logo/signature/QR images सगळं एका zip मध्ये
  static Future<String> createLocalBackup() async {
    final dbPath = await _getDbPath();
    final sourceFile = File(dbPath);
    if (!await sourceFile.exists()) {
      throw Exception('Database सापडला नाही. आधी किमान एक invoice बनवा.');
    }

    final archive = Archive();

    // 1. Database file
    final dbBytes = await sourceFile.readAsBytes();
    archive.addFile(ArchiveFile('database/$_dbName', dbBytes.length, dbBytes));

    // 2. Settings मधल्या images (logo, signatures, UPI QR, location QR)
    try {
      final db = await DatabaseHelper.instance.database;
      final rows = await db.query('settings', where: 'id = ?', whereArgs: [1]);
      if (rows.isNotEmpty) {
        final settings = rows.first;
        for (final entry in _imageFieldMap.entries) {
          final path = (settings[entry.key] as String?) ?? '';
          if (path.isNotEmpty) {
            final imgFile = File(path);
            if (await imgFile.exists()) {
              final ext = path.contains('.') ? path.split('.').last : 'jpg';
              final bytes = await imgFile.readAsBytes();
              archive.addFile(ArchiveFile('images/${entry.value['key']}.$ext', bytes.length, bytes));
            }
          }
        }
      }
    } catch (_) {
      // Images backup मध्ये जोडता आल्या नाहीत तरी database backup चालू राहील
    }

    final zipBytes = ZipEncoder().encode(archive);
    final backupDir = await _getBackupDirectory();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final backupFile = File(join(backupDir.path, 'Anuradha_Backup_$timestamp.zip'));
    await backupFile.writeAsBytes(zipBytes!);
    return backupFile.path;
  }

  static Future<bool> _restoreDbBytes(List<int> dbBytes) async {
    try {
      // Step 1: DatabaseHelper चा singleton पूर्णपणे बंद करणे
      await DatabaseHelper.instance.closeDatabase();

      // Step 2: sqflite चे सर्व connections बंद करणे
      final dbPath = await _getDbPath();
      try {
        final db = await openDatabase(dbPath);
        await db.close();
      } catch (_) {}

      // Step 3: थोडा वेळ थांबणे (file system sync साठी)
      await Future.delayed(const Duration(milliseconds: 300));

      // Step 4: Backup चा database file copy करणे
      await File(dbPath).writeAsBytes(dbBytes, flush: true);

      // Step 5: थोडा वेळ थांबणे
      await Future.delayed(const Duration(milliseconds: 200));

      return true;
    } catch (_) {
      return false;
    }
  }

  // Restore करणे — नवीन (.zip: database + images) आणि जुना (.db: फक्त database) दोन्ही format सपोर्ट करते
  static Future<bool> restoreLocalBackup(String backupFilePath) async {
    try {
      final backupFile = File(backupFilePath);
      if (!await backupFile.exists()) return false;
      final bytes = await backupFile.readAsBytes();

      // जुना backup format — फक्त .db file (images नव्हत्या तेव्हाचा backup)
      if (backupFilePath.toLowerCase().endsWith('.db')) {
        return await _restoreDbBytes(bytes);
      }

      // नवीन backup format — .zip (database + images)
      final archive = ZipDecoder().decodeBytes(bytes);

      ArchiveFile? dbFile;
      for (final f in archive) {
        if (f.name == 'database/$_dbName') { dbFile = f; break; }
      }
      if (dbFile == null) return false;

      final dbRestored = await _restoreDbBytes(dbFile.content as List<int>);
      if (!dbRestored) return false;

      // Images extract करून permanent location मध्ये ठेवणे + settings table मध्ये path update करणे
      final imagesDir = await _getImagesDirectory();
      final Map<String, dynamic> restoredPaths = {};

      // key ('logo','sig1',इ.) वरून settings column आणि file-base शोधण्यासाठी reverse map
      final reverseMap = { for (final e in _imageFieldMap.entries) e.value['key']!: e.key };
      final fileBaseMap = { for (final e in _imageFieldMap.entries) e.value['key']!: e.value['fileBase']! };

      for (final f in archive) {
        if (f.name.startsWith('images/')) {
          final fileName = f.name.substring('images/'.length); // उदा. logo.jpg
          final dotIndex = fileName.lastIndexOf('.');
          if (dotIndex == -1) continue;
          final typeKey = fileName.substring(0, dotIndex);
          final ext = fileName.substring(dotIndex + 1);
          if (!reverseMap.containsKey(typeKey)) continue;

          final destPath = '${imagesDir.path}/${fileBaseMap[typeKey]}.$ext';
          await File(destPath).writeAsBytes(f.content as List<int>, flush: true);
          restoredPaths[reverseMap[typeKey]!] = destPath;
        }
      }

      if (restoredPaths.isNotEmpty) {
        final db = await DatabaseHelper.instance.database;
        await db.update('settings', restoredPaths, where: 'id = ?', whereArgs: [1]);
      }

      return true;
    } catch (_) {
      return false;
    }
  }

  // Backup files यादी (जुने .db आणि नवीन .zip दोन्ही दाखवणे)
  static Future<List<File>> listLocalBackups() async {
    try {
      final backupDir = await _getBackupDirectory();
      if (!await backupDir.exists()) return [];
      final files = backupDir.listSync().whereType<File>()
          .where((f) => f.path.endsWith('.db') || f.path.endsWith('.zip')).toList();
      files.sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
      return files;
    } catch (_) { return []; }
  }
}
