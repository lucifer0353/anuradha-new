import 'dart:io';
import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:sqflite/sqflite.dart';
import '../data/database_helper.dart';
import 'save_path_service.dart';
import 'app_logger.dart';

class BackupService {
  static const String _dbName = 'AnuradhaStores.db';

  // SQLite file नेहमी या bytes ने सुरू होते — backup चा database भाग खरा/खराब
  // झालेला नाही हे तपासण्यासाठी वापरतो (कुठलाही जड dependency न लागता जलद check).
  static const List<int> _sqliteMagicHeader = [
    0x53, 0x51, 0x4C, 0x69, 0x74, 0x65, 0x20, 0x66,
    0x6F, 0x72, 0x6D, 0x61, 0x74, 0x20, 0x33, 0x00,
  ]; // "SQLite format 3\0"

  static bool _isValidSqliteBytes(List<int>? bytes) {
    if (bytes == null || bytes.length < _sqliteMagicHeader.length) return false;
    for (int i = 0; i < _sqliteMagicHeader.length; i++) {
      if (bytes[i] != _sqliteMagicHeader[i]) return false;
    }
    return true;
  }

  static Future<int> _getAndroidSdk() async {
    try {
      final result = await Process.run('getprop', ['ro.build.version.sdk']);
      return int.tryParse(result.stdout.toString().trim()) ?? 21;
    } catch (e) {
      await AppLogger.log('BackupService._getAndroidSdk', e);
      return 21;
    }
  }

  // Permission check + request
  static Future<bool> requestPermissions() async {
    final sdk = await _getAndroidSdk();
    if (sdk >= 30) {
      final status = await Permission.manageExternalStorage.status;
      if (!status.isGranted) {
        final result = await Permission.manageExternalStorage.request();
        return result.isGranted;
      }
      return true;
    } else if (sdk >= 23) {
      final status = await Permission.storage.status;
      if (!status.isGranted) {
        final result = await Permission.storage.request();
        return result.isGranted;
      }
      return true;
    }
    return true;
  }

  static Future<Directory> _getBackupDirectory() async {
    // User ने निवडलेला path
    final userPath = await SavePathService.getBackupPath();
    if (userPath != null && userPath.isNotEmpty) {
      try {
        final userDir = Directory(userPath);
        if (!await userDir.exists()) await userDir.create(recursive: true);
        final testFile = File('${userDir.path}/.test');
        await testFile.writeAsString('test');
        await testFile.delete();
        return userDir;
      } catch (e) {
        await AppLogger.log('BackupService._getBackupDirectory: निवडलेला folder ($userPath) वापरता आला नाही, डीफॉल्ट folder वापरत आहे', e);
      }
    }

    // Default: app-specific external (permission नसली तरी चालते)
    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir != null) {
        final backupDir = Directory('${extDir.path}/Anuradha_Backups');
        if (!await backupDir.exists()) await backupDir.create(recursive: true);
        return backupDir;
      }
    } catch (e) {
      await AppLogger.log('BackupService._getBackupDirectory: external dir मिळाला नाही', e);
    }

    // Fallback: internal
    final appDoc = await getApplicationDocumentsDirectory();
    final fallback = Directory('${appDoc.path}/Anuradha_Backups');
    if (!await fallback.exists()) await fallback.create(recursive: true);
    return fallback;
  }

  static Future<String> _getDbPath() async {
    final docsDir = await getApplicationDocumentsDirectory();
    return join(docsDir.path, _dbName);
  }

  // Logo/Signature/QR images जिथे permanent save होतात, तीच जागा वापरणे
  // (settings_screen.dart मधल्या _saveImagePermanently शी सुसंगत)
  static Future<Directory> _getImagesDirectory() async {
    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir != null) {
        final dir = Directory('${extDir.path}/Anuradha_Images');
        if (!await dir.exists()) await dir.create(recursive: true);
        return dir;
      }
    } catch (e) {
      await AppLogger.log('BackupService._getImagesDirectory: external dir मिळाला नाही', e);
    }
    final appDoc = await getApplicationDocumentsDirectory();
    final dir = Directory('${appDoc.path}/Anuradha_Images');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  // Settings चा कुठला column, backup मधलं कुठलं नाव, आणि restore केल्यावर file चं नाव काय असावं
  static const Map<String, Map<String, String>> _imageFieldMap = {
    'logoPath':       {'key': 'logo',       'fileBase': 'anuradha_logo_image'},
    'sigPath1':       {'key': 'sig1',       'fileBase': 'anuradha_sig_image'},
    'sigPath2':       {'key': 'sig2',       'fileBase': 'anuradha_sig2_image'},
    'qrPath':         {'key': 'qr',         'fileBase': 'anuradha_qr_image'},
    'locationQrPath': {'key': 'locationqr', 'fileBase': 'anuradha_locationqr_image'},
  };

  // Backup बनवणे — database + shop logo/signature/QR images सगळं एका zip मध्ये
  // + बनवल्यानंतर लगेच ती zip file उघडून/तपासून खरी (corrupt नाही) आहे याची खात्री करते.
  static Future<String> createLocalBackup() async {
    final dbPath = await _getDbPath();
    final sourceFile = File(dbPath);
    if (!await sourceFile.exists()) {
      throw Exception('Database सापडला नाही. आधी किमान एक invoice बनवा.');
    }

    final archive = Archive();

    // 1. Database file
    final dbBytes = await sourceFile.readAsBytes();
    if (!_isValidSqliteBytes(dbBytes)) {
      // हे झालं तर आपल्याच phone वरचा live database खराब आहे — backup बनवण्याआधीच थांबवणे बरे
      throw Exception('सध्याचा Database file valid दिसत नाही, Backup बनवणं थांबवलं आहे. कृपया app पुन्हा उघडून प्रयत्न करा.');
    }
    archive.addFile(ArchiveFile('database/$_dbName', dbBytes.length, dbBytes));

    // 2. Settings मधल्या images (logo, signatures, UPI QR, location QR)
    try {
      final db = await DatabaseHelper.instance.database;
      final rows = await db.query('settings', where: 'id = ?', whereArgs: [1]);
      if (rows.isNotEmpty) {
        final settings = rows.first;
        for (final entry in _imageFieldMap.entries) {
          final path = (settings[entry.key] as String?) ?? '';
          if (path.isNotEmpty) {
            final imgFile = File(path);
            if (await imgFile.exists()) {
              final ext = path.contains('.') ? path.split('.').last : 'jpg';
              final bytes = await imgFile.readAsBytes();
              archive.addFile(ArchiveFile('images/${entry.value['key']}.$ext', bytes.length, bytes));
            }
          }
        }
      }
    } catch (e) {
      // Images backup मध्ये जोडता आल्या नाहीत तरी database backup चालू राहील, फक्त log करतो
      await AppLogger.log('BackupService.createLocalBackup: images जोडताना समस्या आली, फक्त database backup झाला', e);
    }

    final zipBytes = ZipEncoder().encode(archive);
    if (zipBytes == null) {
      throw Exception('Backup zip बनवता आली नाही. पुन्हा प्रयत्न करा.');
    }

    final backupDir = await _getBackupDirectory();
    final timestamp = DateTime.now().millisecondsSinceEpoch;
    final backupFile = File(join(backupDir.path, 'Anuradha_Backup_$timestamp.zip'));
    await backupFile.writeAsBytes(zipBytes);

    // ✅ Integrity check: backup बनवल्यानंतर लगेच ती परत उघडून खात्री करणे
    try {
      final verifyBytes = await backupFile.readAsBytes();
      final verifyArchive = ZipDecoder().decodeBytes(verifyBytes);
      ArchiveFile? dbEntry;
      for (final f in verifyArchive.files) {
        if (f.name == 'database/$_dbName') { dbEntry = f; break; }
      }
      if (dbEntry == null || !_isValidSqliteBytes(dbEntry.content as List<int>)) {
        await backupFile.delete().catchError((e) { AppLogger.log('BackupService: corrupt backup delete', e); return backupFile; });
        throw Exception('Backup तयार झाला पण तो सदोष (corrupt) निघाला, म्हणून तो file काढून टाकली आहे. कृपया पुन्हा Backup घ्या.');
      }
    } catch (e) {
      if (e is Exception && e.toString().contains('सदोष')) rethrow;
      await AppLogger.log('BackupService.createLocalBackup: verify टप्प्यात समस्या', e);
      try { await backupFile.delete(); } catch (_) {}
      throw Exception('Backup verify करताना समस्या आली, त्यामुळे ती अपूर्ण file काढून टाकली आहे. कृपया पुन्हा प्रयत्न करा.');
    }

    return backupFile.path;
  }

  static Future<void> _restoreDbBytes(List<int> dbBytes) async {
    // Step 1: DatabaseHelper चा singleton पूर्णपणे बंद करणे
    await DatabaseHelper.instance.closeDatabase();

    // Step 2: sqflite चे सर्व connections बंद करणे
    final dbPath = await _getDbPath();
    try {
      final db = await openDatabase(dbPath);
      await db.close();
    } catch (e) {
      await AppLogger.log('BackupService._restoreDbBytes: जुना db connection बंद करताना', e);
    }

    // Step 3: थोडा वेळ थांबणे (file system sync साठी)
    await Future.delayed(const Duration(milliseconds: 300));

    // Step 4: Backup चा database file copy करणे
    await File(dbPath).writeAsBytes(dbBytes, flush: true);

    // Step 5: थोडा वेळ थांबणे
    await Future.delayed(const Duration(milliseconds: 200));
  }

  // Restore करणे — नवीन (.zip: database + images) आणि जुना (.db: फक्त database) दोन्ही format सपोर्ट करते.
  // महत्त्वाचं: Backup file खरी/valid आहे याची खात्री होईपर्यंत सध्याचा (live) database
  // यात touch केला जात नाही — जेणेकरून एखादी corrupt backup restore केल्यास सध्याचा data बिघडणार नाही.
  // Fail झाल्यास फक्त `false` न देता, नक्की काय चुकलं ते सांगणारा Exception टाकतो.
  static Future<bool> restoreLocalBackup(String backupFilePath) async {
    final backupFile = File(backupFilePath);
    if (!await backupFile.exists()) {
      throw Exception('निवडलेली backup file सापडली नाही.');
    }

    final bytes = await backupFile.readAsBytes();

    // जुना backup format — फक्त .db file (images नव्हत्या तेव्हाचा backup)
    if (backupFilePath.toLowerCase().endsWith('.db')) {
      if (!_isValidSqliteBytes(bytes)) {
        throw Exception('ही backup file सदोष (corrupt) आहे किंवा valid database नाही. दुसरी backup निवडा.');
      }
      await _restoreDbBytes(bytes);
      return true;
    }

    // नवीन backup format — .zip (database + images)
    Archive archive;
    try {
      archive = ZipDecoder().decodeBytes(bytes);
    } catch (e) {
      await AppLogger.log('BackupService.restoreLocalBackup: zip उघडता आली नाही', e);
      throw Exception('ही backup file उघडता आली नाही — ती सदोष (corrupt) असू शकते.');
    }

    final dbFile = () {
      for (final f in archive.files) {
        if (f.name == 'database/$_dbName') return f;
      }
      return null;
    }();
    if (dbFile == null) {
      throw Exception('या backup मध्ये database सापडला नाही — ती backup सदोष असू शकते.');
    }

    final dbBytes = dbFile.content as List<int>;
    if (!_isValidSqliteBytes(dbBytes)) {
      throw Exception('Backup मधला database सदोष (corrupt) निघाला. दुसरी backup निवडा किंवा नवीन backup घ्या.');
    }

    // इथपर्यंत सगळं valid आहे याची खात्री झाली — आताच खरा restore सुरू करणे
    await _restoreDbBytes(dbBytes);

    // Images extract करून permanent location मध्ये ठेवणे + settings table मध्ये path update करणे
    try {
      final imagesDir = await _getImagesDirectory();
      final Map<String, dynamic> restoredPaths = {};

      // key ('logo','sig1',इ.) वरून settings column आणि file-base शोधण्यासाठी reverse map
      final reverseMap = { for (final e in _imageFieldMap.entries) e.value['key']!: e.key };
      final fileBaseMap = { for (final e in _imageFieldMap.entries) e.value['key']!: e.value['fileBase']! };

      for (final f in archive.files) {
        if (f.name.startsWith('images/')) {
          final fileName = f.name.substring('images/'.length); // उदा. logo.jpg
          final dotIndex = fileName.lastIndexOf('.');
          if (dotIndex == -1) continue;
          final typeKey = fileName.substring(0, dotIndex);
          final ext = fileName.substring(dotIndex + 1);
          if (!reverseMap.containsKey(typeKey)) continue;

          final destPath = '${imagesDir.path}/${fileBaseMap[typeKey]}.$ext';
          await File(destPath).writeAsBytes(f.content as List<int>, flush: true);
          restoredPaths[reverseMap[typeKey]!] = destPath;
        }
      }

      if (restoredPaths.isNotEmpty) {
        final db = await DatabaseHelper.instance.database;
        await db.update('settings', restoredPaths, where: 'id = ?', whereArgs: [1]);
      }
    } catch (e) {
      // Database आधीच व्यवस्थित restore झालाय — फक्त images restore मध्ये अडचण आली तर तेवढंच log करून पुढे जाणे
      await AppLogger.log('BackupService.restoreLocalBackup: images restore करताना समस्या (database मात्र restore झाला आहे)', e);
    }

    return true;
  }

  // Backup files यादी (जुने .db आणि नवीन .zip दोन्ही दाखवणे)
  static Future<List<File>> listLocalBackups() async {
    try {
      final backupDir = await _getBackupDirectory();
      if (!await backupDir.exists()) return [];
      final files = backupDir.listSync().whereType<File>()
          .where((f) => f.path.endsWith('.db') || f.path.endsWith('.zip')).toList();
      files.sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
      return files;
    } catch (e) {
      await AppLogger.log('BackupService.listLocalBackups', e);
      return [];
    }
  }
}
