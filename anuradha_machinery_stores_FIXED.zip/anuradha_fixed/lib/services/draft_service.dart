import 'dart:convert';
import 'package:sqflite/sqflite.dart';
import '../data/database_helper.dart';
import '../data/models/invoice_model.dart';
import '../data/models/customer_model.dart';

// Draft save/restore service
class DraftService {
  static final _db = DatabaseHelper.instance;

  // Draft save करणे — प्रत्येक change नंतर call करा
  static Future<void> saveDraft({
    CustomerModel? customer,
    List<InvoiceItemModel> items = const [],
    String paymentStatus = 'Paid',
    double billDiscountPct = 0,
    double billDiscountAmt = 0,
    bool billDiscountIsPercent = true,
  }) async {
    try {
      final db = await _db.database;
      final now = DateTime.now().toIso8601String();

      // Items serialize करणे
      final itemsData = items.map((item) => {
        'productName': item.productName,
        'hsnCode': item.hsnCode,
        'cmlNumber': item.cmlNumber,
        'batchNumber': item.batchNumber,
        'quantity': item.quantity,
        'unit': item.unit,
        'companyRate': item.companyRate,
        'saleRate': item.saleRate,
        'discountPct': item.discountPct,
        'discountAmt': item.discountAmt,
        'discountedRate': item.discountedRate,
        'gstPercentage': item.gstPercentage,
        'amount': item.amount,
      }).toList();

      final draftData = jsonEncode({
        'customer': customer != null ? {
          'id': customer.id,
          'name': customer.name,
          'mobile': customer.mobile,
          'address': customer.address,
          'state': customer.state,
          'district': customer.district,
          'subDistrict': customer.subDistrict,
          'stateCode': customer.stateCode,
          'areaUnit': customer.areaUnit,
          'gatNumber': customer.gatNumber,
          'area': customer.area,
          'crop': customer.crop,
          'gstin': customer.gstin,
          'remarks': customer.remarks,
        } : null,
        'items': itemsData,
        'paymentStatus': paymentStatus,
        'billDiscountPct': billDiscountPct,
        'billDiscountAmt': billDiscountAmt,
        'billDiscountIsPercent': billDiscountIsPercent,
      });

      // Upsert — एकच draft राहतो
      await db.insert('invoice_draft', {
        'id': 1,
        'draftData': draftData,
        'updatedAt': now,
      }, conflictAlgorithm: ConflictAlgorithm.replace);
    } catch (_) {}
  }

  // Draft आहे का check करणे
  static Future<bool> hasDraft() async {
    try {
      final db = await _db.database;
      final result = await db.query('invoice_draft', where: 'id = ?', whereArgs: [1]);
      if (result.isEmpty) return false;

      final data = jsonDecode(result.first['draftData'] as String);
      final items = data['items'] as List? ?? [];
      final customer = data['customer'];
      // Draft meaningful आहे का — customer किंवा items असायला हवेत
      return customer != null || items.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  // Draft load करणे
  static Future<Map<String, dynamic>?> loadDraft() async {
    try {
      final db = await _db.database;
      final result = await db.query('invoice_draft', where: 'id = ?', whereArgs: [1]);
      if (result.isEmpty) return null;

      final raw = jsonDecode(result.first['draftData'] as String);
      final updatedAt = result.first['updatedAt'] as String;

      // Customer restore
      CustomerModel? customer;
      if (raw['customer'] != null) {
        final c = raw['customer'] as Map<String, dynamic>;
        customer = CustomerModel(
          id: c['id'],
          name: c['name'] ?? '',
          mobile: c['mobile'] ?? '',
          address: c['address'] ?? '',
          state: c['state'] ?? '',
          district: c['district'] ?? '',
          subDistrict: c['subDistrict'] ?? '',
          stateCode: c['stateCode'] ?? '',
          areaUnit: c['areaUnit'] ?? 'Acre (एकर)',
          gatNumber: c['gatNumber'] ?? '',
          area: c['area'] ?? '',
          crop: c['crop'] ?? '',
          gstin: c['gstin'] ?? '',
          remarks: c['remarks'] ?? '',
        );
      }

      // Items restore
      final itemsList = (raw['items'] as List? ?? []).map<InvoiceItemModel>((i) {
        final saleRate = (i['saleRate'] as num?)?.toDouble() ?? 0.0;
        return InvoiceItemModel(
          productName: i['productName'] ?? '',
          hsnCode: i['hsnCode'] ?? '',
          cmlNumber: i['cmlNumber'] ?? '',
          batchNumber: i['batchNumber'] ?? '',
          quantity: (i['quantity'] as num?)?.toDouble() ?? 1.0,
          unit: i['unit'] ?? 'Piece',
          companyRate: (i['companyRate'] as num?)?.toDouble() ?? 0.0,
          saleRate: saleRate,
          discountPct: (i['discountPct'] as num?)?.toDouble() ?? 0.0,
          discountAmt: (i['discountAmt'] as num?)?.toDouble() ?? 0.0,
          discountedRate: (i['discountedRate'] as num?)?.toDouble() ?? saleRate,
          gstPercentage: (i['gstPercentage'] as num?)?.toDouble() ?? 0.0,
          amount: (i['amount'] as num?)?.toDouble() ?? 0.0,
        );
      }).toList();

      return {
        'customer': customer,
        'items': itemsList,
        'paymentStatus': raw['paymentStatus'] ?? 'Paid',
        'billDiscountPct': (raw['billDiscountPct'] as num?)?.toDouble() ?? 0.0,
        'billDiscountAmt': (raw['billDiscountAmt'] as num?)?.toDouble() ?? 0.0,
        'billDiscountIsPercent': raw['billDiscountIsPercent'] ?? true,
        'updatedAt': updatedAt,
      };
    } catch (_) {
      return null;
    }
  }

  // Draft delete करणे — invoice save झाल्यावर
  static Future<void> deleteDraft() async {
    try {
      final db = await _db.database;
      await db.delete('invoice_draft', where: 'id = ?', whereArgs: [1]);
    } catch (_) {}
  }
}
