import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

/// साधा error logger.
/// आधी बरेच ठिकाणी `catch (_) {}` वापरून error पूर्णपणे गिळला जायचा —
/// यामुळे feature silently fail व्हायचं आणि कारण कधीच कळायचं नाही.
/// आता प्रत्येक महत्त्वाच्या catch मध्ये किमान हा logger call होईल,
/// जेणेकरून काय चुकलं हे नंतर बघता येईल (debugPrint + local log file).
class AppLogger {
  static Future<File> _getLogFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/anuradha_error_log.txt');
  }

  /// एखादी error/exception लॉग करणे. हे स्वतःच fail झालं तरी app वर परिणाम होणार नाही.
  static Future<void> log(String context, Object error) async {
    final message = '[${DateTime.now()}] $context => $error';
    debugPrint('AMS_LOG: $message');
    try {
      final file = await _getLogFile();
      await file.writeAsString('$message\n', mode: FileMode.append, flush: true);
    } catch (_) {
      // Logging स्वतःच fail झाली तरी app crash होता कामा नये,
      // म्हणून इथे फक्त debugPrint वर सोडून देतो.
    }
  }

  /// अलीकडचे errors वाचण्यासाठी (गरज पडल्यास Settings मध्ये दाखवता येतील)
  static Future<String> readRecentLogs({int maxChars = 5000}) async {
    try {
      final file = await _getLogFile();
      if (!await file.exists()) return 'कुठलाही error log सापडला नाही.';
      final content = await file.readAsString();
      if (content.length <= maxChars) return content;
      return content.substring(content.length - maxChars);
    } catch (e) {
      return 'Log वाचता आला नाही: $e';
    }
  }

  static Future<void> clearLogs() async {
    try {
      final file = await _getLogFile();
      if (await file.exists()) await file.delete();
    } catch (_) {}
  }
}
