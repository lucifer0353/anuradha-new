import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';

class SavePathService {
  static const String _fileName = 'anuradha_config.txt';
  static const String _pdfKey = 'pdf_path';
  static const String _backupKey = 'backup_path';

  static Future<File?> _getConfigFile() async {
    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir != null) return File(join(extDir.path, _fileName));
    } catch (_) {}
    try {
      final appDir = await getApplicationDocumentsDirectory();
      return File(join(appDir.path, _fileName));
    } catch (_) {}
    return null;
  }

  static Future<Map<String, String>> _readConfig() async {
    try {
      final file = await _getConfigFile();
      if (file == null || !await file.exists()) return {};
      final lines = await file.readAsLines();
      final config = <String, String>{};
      for (final line in lines) {
        final idx = line.indexOf('=');
        if (idx > 0) {
          config[line.substring(0, idx).trim()] = line.substring(idx + 1).trim();
        }
      }
      return config;
    } catch (_) {
      return {};
    }
  }

  static Future<void> _writeConfig(Map<String, String> config) async {
    try {
      final file = await _getConfigFile();
      if (file == null) return;
      final lines = config.entries.map((e) => '${e.key}=${e.value}').toList();
      await file.writeAsString(lines.join('\n'), flush: true);
    } catch (_) {}
  }

  static Future<void> setSavePath(String path) async {
    final config = await _readConfig();
    config[_pdfKey] = path;
    await _writeConfig(config);
  }

  // PDF save path — user selected असेल तर तोच, नाहीतर null
  static Future<String?> getSavePath() async {
    final config = await _readConfig();
    final path = config[_pdfKey];
    if (path != null && path.isNotEmpty) {
      try {
        final dir = Directory(path);
        if (!await dir.exists()) {
          await dir.create(recursive: true);
        }
        // Write access test
        final test = File(join(path, '.ams_test'));
        await test.writeAsString('ok');
        await test.delete();
        return path;
      } catch (_) {
        // Path exists but no write access — return null, fallback होईल
        return null;
      }
    }
    return null;
  }

  static Future<void> setBackupPath(String path) async {
    final config = await _readConfig();
    config[_backupKey] = path;
    await _writeConfig(config);
  }

  static Future<String?> getBackupPath() async {
    final config = await _readConfig();
    final path = config[_backupKey];
    if (path != null && path.isNotEmpty) {
      try {
        final dir = Directory(path);
        if (!await dir.exists()) {
          await dir.create(recursive: true);
        }
        final test = File(join(path, '.ams_test'));
        await test.writeAsString('ok');
        await test.delete();
        return path;
      } catch (_) {
        return null;
      }
    }
    return null;
  }

  // Settings screen साठी — currently saved paths दाखवायला
  static Future<String> getSavePathDisplay() async {
    final config = await _readConfig();
    return config[_pdfKey] ?? '';
  }

  static Future<String> getBackupPathDisplay() async {
    final config = await _readConfig();
    return config[_backupKey] ?? '';
  }
}
