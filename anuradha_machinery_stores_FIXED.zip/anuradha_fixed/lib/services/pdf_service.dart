import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:share_plus/share_plus.dart';
import 'package:open_filex/open_filex.dart';
import '../data/models/invoice_model.dart';
import '../data/models/settings_model.dart';
import 'save_path_service.dart';

class AMSInvoicePdfEngine {

  static Future<pw.Font> _getRegularFont() async {
    final data = await rootBundle.load('assets/fonts/OpenSans-Regular.ttf');
    return pw.Font.ttf(data);
  }

  static Future<pw.Font> _getBoldFont() async {
    final data = await rootBundle.load('assets/fonts/OpenSans-Bold.ttf');
    return pw.Font.ttf(data);
  }

  static Future<pw.Font> _getTitleFont() async {
    final data = await rootBundle.load('assets/fonts/Merriweather-Bold.ttf');
    return pw.Font.ttf(data);
  }

  static Future<pw.Font> _getDevanagariFont() async {
    final data = await rootBundle.load('assets/fonts/NotoSansDevanagari-Regular.ttf');
    return pw.Font.ttf(data);
  }

  static Future<pw.Font> _getDevanagariBoldFont() async {
    final data = await rootBundle.load('assets/fonts/NotoSansDevanagari-Bold.ttf');
    return pw.Font.ttf(data);
  }

  // Fix 3: Save directory — user selected path प्रथम try करतो
  static Future<Directory> _getSaveDirectory() async {
    // 1. User ने निवडलेला path
    try {
      final userPath = await SavePathService.getSavePath();
      if (userPath != null && userPath.isNotEmpty) {
        final userDir = Directory(userPath);
        if (!await userDir.exists()) await userDir.create(recursive: true);
        // Write test
        final testFile = File('${userDir.path}/.writetest');
        await testFile.writeAsString('test');
        await testFile.delete();
        return userDir;
      }
    } catch (_) {}

    // 2. App-specific external storage
    try {
      final extDir = await getExternalStorageDirectory();
      if (extDir != null) {
        final dir = Directory('${extDir.path}/Anuradha_Invoices');
        if (!await dir.exists()) await dir.create(recursive: true);
        return dir;
      }
    } catch (_) {}

    // 3. Internal app documents
    final appDir = await getApplicationDocumentsDirectory();
    final dir = Directory('${appDir.path}/Anuradha_Invoices');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  // Fix: PDF bytes ला दिलेल्या page format नुसार तयार करणे.
  // हेच function Print action साठी वापरलं जातं, जेणेकरून Android च्या native
  // Print dialog मध्ये user जो paper size निवडेल (A4/A5/Letter/Legal इ.),
  // त्याच size नुसार invoice परत तयार (reflow) होईल — फक्त stretch/crop नाही.
  static Future<Uint8List> _buildPdfBytes(InvoiceModel invoice, SettingsModel settings, PdfPageFormat format) async {
    final titleFont   = await _getTitleFont();
    final boldFont    = await _getBoldFont();
    final regularFont = await _getRegularFont();
    final devFont     = await _getDevanagariFont();
    final devBoldFont = await _getDevanagariBoldFont();

    pw.MemoryImage? logoImage;
    pw.MemoryImage? sigImage;
    pw.MemoryImage? qrImage;
    pw.MemoryImage? locationQrImage;

    if (settings.logoPath.isNotEmpty && File(settings.logoPath).existsSync())
      logoImage = pw.MemoryImage(File(settings.logoPath).readAsBytesSync());
    if (settings.sigPath1.isNotEmpty && File(settings.sigPath1).existsSync())
      sigImage = pw.MemoryImage(File(settings.sigPath1).readAsBytesSync());
    if (settings.qrPath.isNotEmpty && File(settings.qrPath).existsSync())
      qrImage = pw.MemoryImage(File(settings.qrPath).readAsBytesSync());
    if (settings.locationQrPath.isNotEmpty && File(settings.locationQrPath).existsSync())
      locationQrImage = pw.MemoryImage(File(settings.locationQrPath).readAsBytesSync());

    // Fix 2: Dynamic columns — only show if data exists
    final items = invoice.items;
    final hasHSN      = items.any((i) => i.hsnCode.isNotEmpty && i.hsnCode != '0' && i.hsnCode != '-');
    final hasCML      = items.any((i) => i.cmlNumber.isNotEmpty && i.cmlNumber != '-');
    final hasBatch    = items.any((i) => i.batchNumber.isNotEmpty && i.batchNumber != '0' && i.batchNumber != '-');
    final hasDiscount = items.any((i) => i.discountPct > 0 || i.discountAmt > 0);
    final hasCompRate = items.any((i) => i.companyRate > 0);

    // Build dynamic headers
    final List<String> headers = ['Sr.', 'Description Of Goods/\nProduct Name/Items'];
    if (hasHSN)      headers.add('HSN/SAC');
    if (hasCML)      headers.add('CML No.');
    if (hasBatch)    headers.add('Batch');
    headers.addAll(['Qty', 'Unit']);
    if (hasCompRate) headers.add('Comp. Rate');
    headers.add('Sale Rate');
    if (hasDiscount) { headers.add('Disc.'); headers.add('Net Rate'); }
    headers.addAll(['GST %', 'Amount']);

    // Build dynamic data rows
    final List<List<String>> tableData = List.generate(items.length, (idx) {
      final item = items[idx];
      final row = <String>['${idx + 1}', item.productName];
      if (hasHSN)   row.add(item.hsnCode.isNotEmpty && item.hsnCode != '0' ? item.hsnCode : '-');
      if (hasCML)   row.add(item.cmlNumber.isNotEmpty ? item.cmlNumber : '-');
      if (hasBatch) row.add(item.batchNumber.isNotEmpty && item.batchNumber != '0' ? item.batchNumber : '-');
      row.add(item.quantity.toString());
      row.add(item.unit);
      if (hasCompRate) row.add(item.companyRate > 0 ? 'Rs.${item.companyRate.toStringAsFixed(2)}' : '-');
      row.add('Rs.${item.saleRate.toStringAsFixed(2)}');
      if (hasDiscount) {
        String discStr = '-';
        if (item.discountPct > 0) discStr = '${item.discountPct.toStringAsFixed(1)}%';
        else if (item.discountAmt > 0) discStr = 'Rs.${item.discountAmt.toStringAsFixed(2)}';
        row.add(discStr);
        row.add('Rs.${item.discountedRate.toStringAsFixed(2)}');
      }
      row.add('${item.gstPercentage}%');
      row.add('Rs.${item.amount.toStringAsFixed(2)}');
      return row;
    });

    // Dynamic column widths
    final Map<int, pw.TableColumnWidth> colWidths = {};
    int ci = 0;
    colWidths[ci++] = const pw.FixedColumnWidth(22);
    colWidths[ci++] = const pw.FlexColumnWidth(2.5);
    if (hasHSN)      colWidths[ci++] = const pw.FixedColumnWidth(32);
    if (hasCML)      colWidths[ci++] = const pw.FixedColumnWidth(36);
    if (hasBatch)    colWidths[ci++] = const pw.FixedColumnWidth(30);
    colWidths[ci++] = const pw.FixedColumnWidth(22);
    colWidths[ci++] = const pw.FixedColumnWidth(26);
    if (hasCompRate) colWidths[ci++] = const pw.FixedColumnWidth(44);
    colWidths[ci++] = const pw.FixedColumnWidth(44);
    if (hasDiscount) { colWidths[ci++] = const pw.FixedColumnWidth(36); colWidths[ci++] = const pw.FixedColumnWidth(44); }
    colWidths[ci++] = const pw.FixedColumnWidth(26);
    colWidths[ci++] = const pw.FixedColumnWidth(50);

    // Text style helper
    pw.TextStyle ts(pw.Font f, {double sz = 9, bool bold = false, PdfColor? color}) =>
      pw.TextStyle(font: f, fontFallback: [f == boldFont || f == titleFont ? devBoldFont : devFont],
        fontSize: sz, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal, color: color);

    // Build a MultiPage for one copy
    pw.MultiPage buildCopyPage(String copyLabel) {
      return pw.MultiPage(
        pageFormat: format.copyWith(marginTop: 16, marginBottom: 16, marginLeft: 24, marginRight: 24),
        header: (ctx) => pw.Column(children: [
          // Copy label top-left
          pw.Align(
            alignment: pw.Alignment.topLeft,
            child: pw.Text(copyLabel,
              style: pw.TextStyle(font: regularFont, fontFallback: [devFont],
                fontSize: 7, color: PdfColors.grey600)),
          ),
          pw.SizedBox(height: 2),
          // Shop header
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.center,
            children: [
              if (logoImage != null) pw.Image(logoImage!, width: 55, height: 55) else pw.SizedBox(width: 55),
              pw.Expanded(child: pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.center,
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Text('ANURADHA MACHINERY STORES',
                    style: pw.TextStyle(font: titleFont, fontFallback: [devBoldFont],
                      fontSize: 21, color: PdfColor.fromHex('#D32F2F')),
                    textAlign: pw.TextAlign.center),
                  pw.SizedBox(height: 2),
                  if (settings.address.isNotEmpty)
                    pw.Text(settings.address, style: ts(regularFont, sz: 8.5), textAlign: pw.TextAlign.center),
                ],
              )),
              if (locationQrImage != null)
                pw.Column(mainAxisSize: pw.MainAxisSize.min, children: [
                  if (settings.jurisdiction.isNotEmpty)
                    pw.Text(settings.jurisdiction,
                      style: pw.TextStyle(font: boldFont, fontFallback: [devBoldFont],
                        fontSize: 8, color: PdfColors.black, fontWeight: pw.FontWeight.bold)),
                  pw.Image(locationQrImage!, width: 52, height: 52),
                  pw.Text('Shop Location', style: ts(regularFont, sz: 7, color: PdfColors.grey700)),
                ])
              else pw.SizedBox(width: 55),
            ],
          ),
          pw.SizedBox(height: 4),
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.symmetric(vertical: 4, horizontal: 6),
            decoration: pw.BoxDecoration(color: PdfColor.fromHex('#F0F0F0'), borderRadius: pw.BorderRadius.circular(4)),
            child: pw.Column(children: [
              if (settings.gstin.isNotEmpty || settings.authorizedDealer.isNotEmpty)
                pw.Text(
                  [if (settings.gstin.isNotEmpty) 'GSTIN: ${settings.gstin}',
                   if (settings.authorizedDealer.isNotEmpty) 'Authorized Dealer: ${settings.authorizedDealer}'].join(' | '),
                  style: ts(boldFont, sz: 8.5), textAlign: pw.TextAlign.center),
              if (settings.mobile1.isNotEmpty || settings.email1.isNotEmpty)
                pw.Text(
                  [if (settings.mobile1.isNotEmpty) 'Contact: ${settings.mobile1}${settings.mobile2.isNotEmpty ? ", ${settings.mobile2}" : ""}',
                   if (settings.email1.isNotEmpty) 'Email: ${settings.email1}'].join(' | '),
                  style: ts(regularFont, sz: 8.5), textAlign: pw.TextAlign.center),
            ]),
          ),
          pw.SizedBox(height: 4),
          pw.Divider(thickness: 1.5, color: PdfColor.fromHex('#D32F2F')),
          // TAX INVOICE label
          pw.Center(child: pw.Text('TAX INVOICE',
            style: pw.TextStyle(font: boldFont, fontFallback: [devBoldFont],
              fontSize: 8, color: PdfColor.fromHex('#D32F2F'), letterSpacing: 2))),
          pw.SizedBox(height: 4),
        ]),
        footer: (ctx) => pw.Column(children: [
          pw.Divider(thickness: 0.5, color: PdfColors.grey400),
          pw.Text('*This is a computer generated invoice.',
            style: ts(regularFont, sz: 6.5, color: PdfColors.grey600),
            textAlign: pw.TextAlign.center),
        ]),
        build: (ctx) => [
          pw.SizedBox(height: 6),
          // Customer details + Invoice details (swapped positions)
          pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Expanded(flex: 5, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('BILL TO (CUSTOMER)', style: ts(boldFont, sz: 10, color: PdfColors.blueGrey900)),
              pw.SizedBox(height: 4),
              pw.Text(invoice.customerName, style: ts(boldFont, sz: 10)),
              if (invoice.customerMobile.isNotEmpty)
                pw.Text('Mobile: ${invoice.customerMobile}', style: ts(regularFont, sz: 9)),
              if (invoice.customerAddress.isNotEmpty)
                pw.Text('${invoice.customerAddress}', style: ts(regularFont, sz: 9)),
              if (invoice.customerSubDistrict.isNotEmpty)
                pw.Text('Taluka: ${invoice.customerSubDistrict}', style: ts(regularFont, sz: 9)),
              if (invoice.customerDistrict.isNotEmpty)
                pw.Text('Dist: ${invoice.customerDistrict}', style: ts(regularFont, sz: 9)),
              if (invoice.customerState.isNotEmpty)
                pw.Text('${invoice.customerState}${invoice.customerStateCode.isNotEmpty ? " (${invoice.customerStateCode})" : ""}',
                  style: ts(regularFont, sz: 9)),
              if (invoice.customerGat.isNotEmpty)
                pw.Text('Gat/Survey No: ${invoice.customerGat}', style: ts(regularFont, sz: 9)),
              if (invoice.customerArea.isNotEmpty)
                pw.Text('Area: ${invoice.customerArea}${invoice.customerAreaUnit.isNotEmpty ? " ${invoice.customerAreaUnit}" : ""}',
                  style: ts(regularFont, sz: 9)),
              if (invoice.customerCrop.isNotEmpty)
                pw.Text('Crop: ${invoice.customerCrop}', style: ts(regularFont, sz: 9)),
              if (invoice.customerRemarks.isNotEmpty)
                pw.Text('Remarks: ${invoice.customerRemarks}', style: ts(regularFont, sz: 9)),
              if (invoice.customerGstin.isNotEmpty && invoice.customerGstin != '0')
                pw.Text('GSTIN: ${invoice.customerGstin}', style: ts(boldFont, sz: 9)),
            ])),
            pw.Expanded(flex: 5, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('INVOICE DETAILS', style: ts(boldFont, sz: 10, color: PdfColors.blueGrey900)),
              pw.SizedBox(height: 4),
              pw.Text('Invoice No: ${invoice.invoiceNumber}', style: ts(boldFont, sz: 10)),
              pw.Text('Date: ${invoice.date}', style: ts(regularFont, sz: 9)),
              pw.Text('Time: ${invoice.time}', style: ts(regularFont, sz: 9)),
            ])),
          ]),
          pw.SizedBox(height: 12),
          // Items Table
          pw.TableHelper.fromTextArray(
            headers: headers,
            data: tableData,
            headerStyle: pw.TextStyle(font: boldFont, fontFallback: [devBoldFont], fontSize: 7.5, color: PdfColors.white),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.blueGrey900),
            cellAlignment: pw.Alignment.centerLeft,
            cellStyle: pw.TextStyle(font: regularFont, fontFallback: [devFont], fontSize: 7.5),
            columnWidths: colWidths,
          ),
          pw.SizedBox(height: 12),
          // Bank + Totals
          pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Expanded(flex: 5, child: pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
              pw.Text('BANK DETAILS', style: ts(boldFont, sz: 9, color: PdfColors.blueGrey900)),
              if (settings.bankName.isNotEmpty)   pw.Text('Bank: ${settings.bankName}', style: ts(regularFont, sz: 8)),
              if (settings.accName.isNotEmpty)    pw.Text('A/C Name: ${settings.accName}', style: ts(regularFont, sz: 8)),
              if (settings.accNumber.isNotEmpty)  pw.Text('A/C No: ${settings.accNumber}', style: ts(regularFont, sz: 8)),
              if (settings.ifscCode.isNotEmpty)   pw.Text('IFSC: ${settings.ifscCode}', style: ts(regularFont, sz: 8)),
              if (settings.upiId.isNotEmpty)      pw.Text('UPI: ${settings.upiId}', style: ts(regularFont, sz: 8)),
              if (qrImage != null) ...[
                pw.SizedBox(height: 6),
                pw.Text('SCAN TO PAY', style: ts(boldFont, sz: 8, color: PdfColors.green900)),
                pw.SizedBox(height: 4),
                pw.Image(qrImage!, width: 65, height: 65),
              ],
            ])),
            pw.Expanded(flex: 5, child: pw.Container(
              padding: const pw.EdgeInsets.all(6),
              decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.grey300), borderRadius: pw.BorderRadius.circular(4)),
              child: pw.Column(children: [
                if (invoice.billDiscount > 0) ...[
                  _pdfRow('Product Total:', 'Rs. ${(invoice.taxableAmount + invoice.billDiscount).toStringAsFixed(2)}', regularFont, devFont),
                  _pdfRow('Bill Discount:', '- Rs. ${invoice.billDiscount.toStringAsFixed(2)}', regularFont, devFont),
                ],
                _pdfRow('Taxable Amount:', 'Rs. ${invoice.taxableAmount.toStringAsFixed(2)}', regularFont, devFont),
                _pdfRow('CGST:', 'Rs. ${invoice.cgst.toStringAsFixed(2)}', regularFont, devFont),
                _pdfRow('SGST:', 'Rs. ${invoice.sgst.toStringAsFixed(2)}', regularFont, devFont),
                pw.Divider(thickness: 1, color: PdfColors.grey300),
                _pdfRow('Grand Total:', 'Rs. ${invoice.grandTotal.toStringAsFixed(2)}', boldFont, devBoldFont, isBold: true),
                if (invoice.roundOff != 0) ...[
                  _pdfRow('Round Off:', '${invoice.roundOff >= 0 ? "+" : ""}Rs. ${invoice.roundOff.toStringAsFixed(2)}', regularFont, devFont),
                  pw.Divider(thickness: 1, color: PdfColors.grey300),
                  _pdfRow('Final Payable:', 'Rs. ${invoice.finalAmount.toStringAsFixed(2)}', boldFont, devBoldFont, isBold: true),
                ],
              ]),
            )),
          ]),
          pw.SizedBox(height: 8),
          pw.Text('Amount in Words: ${invoice.amountInWords}', style: ts(boldFont, sz: 9)),
          pw.SizedBox(height: 10),
          if (settings.terms.isNotEmpty) ...[
            pw.Text('TERMS & CONDITIONS:', style: ts(boldFont, sz: 8, color: PdfColors.grey800)),
            pw.Text(settings.terms, style: ts(regularFont, sz: 7, color: PdfColors.grey700)),
          ],
          if (settings.declaration.isNotEmpty) ...[
            pw.SizedBox(height: 6),
            pw.Text('DECLARATION:', style: ts(boldFont, sz: 8, color: PdfColors.grey800)),
            pw.Text(settings.declaration, style: ts(regularFont, sz: 7, color: PdfColors.grey700)),
          ],
          pw.Spacer(),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Column(children: [
                pw.SizedBox(height: 30),
                pw.Container(width: 100, child: pw.Divider(thickness: 0.5)),
                pw.Text('Customer Signature', style: ts(regularFont, sz: 8)),
              ]),
              pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
                pw.Text('For ANURADHA MACHINERY STORES', style: ts(boldFont, sz: 8)),
                if (sigImage != null) ...[
                  pw.SizedBox(height: 4),
                  pw.Image(sigImage!, width: 80, height: 30, fit: pw.BoxFit.contain),
                  pw.SizedBox(height: 4),
                ] else pw.SizedBox(height: 35),
                pw.Text(settings.ownerName1.isNotEmpty ? settings.ownerName1.toUpperCase() : 'AUTHORIZED SIGNATORY',
                  style: ts(boldFont, sz: 8)),
                if (settings.designation1.isNotEmpty)
                  pw.Text('(${settings.designation1})', style: ts(regularFont, sz: 7)),
              ]),
            ],
          ),
        ],
      );
    }

    final pdf = pw.Document();
    pdf.addPage(buildCopyPage('Original Copy'));
    pdf.addPage(buildCopyPage('Duplicate Copy'));
    return pdf.save();
  }

  // Save/Share/History साठी वापरली जाणारी PDF file — यासाठी default A4 वापरतो
  static Future<File> generateInvoicePdf(InvoiceModel invoice, SettingsModel settings) async {
    final bytes = await _buildPdfBytes(invoice, settings, PdfPageFormat.a4);
    final saveDir = await _getSaveDirectory();
    final safeName = invoice.invoiceNumber.replaceAll('/', '-').replaceAll(' ', '_');
    final file = File('${saveDir.path}/$safeName.pdf');
    await file.writeAsBytes(bytes);
    return file;
  }

  static Future<void> showPdfOptions(BuildContext context, File pdfFile, String invoiceNumber,
      InvoiceModel invoice, SettingsModel settings) async {
    await showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('Invoice PDF Ready! 🎉', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            Text(pdfFile.path, style: const TextStyle(fontSize: 11, color: Colors.grey),
              maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _optionBtn(Icons.picture_as_pdf, 'Open PDF', Colors.red, () async {
                  Navigator.pop(ctx);
                  await OpenFilex.open(pdfFile.path);
                }),
                _optionBtn(Icons.share, 'Share / WhatsApp', Colors.blue, () async {
                  Navigator.pop(ctx);
                  await Share.shareXFiles([XFile(pdfFile.path)],
                    text: 'Invoice $invoiceNumber - Anuradha Machinery Stores');
                }),
                _optionBtn(Icons.print, 'Print', Colors.green, () async {
                  Navigator.pop(ctx);
                  // Android च्या Print dialog मध्ये user जो paper size (A4/A5/Letter/Legal इ.)
                  // निवडेल, त्यानुसारच invoice नव्याने तयार (reflow) होतो — auto-fit.
                  await Printing.layoutPdf(
                    onLayout: (PdfPageFormat pdfFormat) async =>
                        _buildPdfBytes(invoice, settings, pdfFormat),
                    name: '$invoiceNumber.pdf',
                  );
                }),
              ],
            ),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  static Widget _optionBtn(IconData icon, String label, Color color, VoidCallback onTap) =>
    Column(children: [
      IconButton(iconSize: 40, icon: Icon(icon, color: color), onPressed: onTap),
      Text(label, style: const TextStyle(fontSize: 11)),
    ]);

  static pw.Row _pdfRow(String label, String val, pw.Font font, pw.Font devFont, {bool isBold = false}) {
    final style = pw.TextStyle(
      font: font, fontFallback: [devFont], fontSize: 9,
      fontWeight: isBold ? pw.FontWeight.bold : pw.FontWeight.normal,
    );
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [pw.Text(label, style: style), pw.Text(val, style: style)],
    );
  }
}
